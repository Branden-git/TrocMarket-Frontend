import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Alert, StatusBar, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useAuthStore } from '../../store/authStore';
import { authService } from '../../services/api';
import { COLORS } from '../../constants';

type Onglet = 'inscription' | 'connexion';

export default function Inscription() {
  const [onglet, setOnglet] = useState<Onglet>('inscription');

  // Inscription
  const [nom, setNom]             = useState('');
  const [identifiant, setIdent]   = useState(''); // email ou tel
  const [motdepasse, setMdp]      = useState('');
  const [showMdp, setShowMdp]     = useState(false);
  const [cgu, setCgu]             = useState(false);

  // Connexion
  const [loginIdent, setLoginId]  = useState('');
  const [loginMdp, setLoginMdp]   = useState('');
  const [showLoginMdp, setShowLMdp] = useState(false);

  const [loading, setLoading]     = useState(false);
  const { setAuth } = useAuthStore();

  // Détermine si l'identifiant est un email ou un tel
  const isEmail = (v: string) => v.includes('@');

  const normaliserTel = (v: string) => {
    const t = v.replaceAll(/[\s\-]/g, '');
    return t.startsWith('+') ? t : `+237${t}`;
  };

const doInscription = async () => {
  const nomClean = nom.trim();
  const identifiantClean = identifiant.trim();

  if (!nomClean) { Alert.alert('Erreur', 'Nom requis'); return; }
  if (!identifiantClean) { Alert.alert('Erreur', 'Email ou Tel requis'); return; }

  setLoading(true);
  try {
  const estEmail = identifiantClean.includes('@');
  
  const payload = {
    nom: nomClean,
    // On envoie une chaîne vide plutôt que null si c'est un tel, 
    // pour éviter des bugs de validation sur certains serveurs
    email: estEmail ? identifiantClean.toLowerCase() : "", 
    telephone: estEmail ? "" : normaliserTel(identifiantClean),
    password: motdepasse,
    ville: 'Yaoundé',
    quartier: '',
  };

  const { data } = await authService.register(payload);

  // IMPORTANT : On utilise 'data.email' qui vient du serveur 
  // car le serveur aura généré le "@trocmarket.cm"
  await setAuth({
    id: data.userId,
    nom: data.nom,
    email: data.email, // C'est ici que tu récupères l'email généré
    telephone: data.telephone,
    scoreReputation: 0,
    nombreEchanges: 0,
  }, data.token);

  router.replace('/(auth)/zone');
  } catch (e: any) {
    console.log("ERREUR SERVEUR :", e.response?.data);
    Alert.alert('Erreur', e.response?.data || "Échec inscription");
  } finally {
    setLoading(false);
  }
};

  const doConnexion = async () => {
  if (!loginIdent.trim()) { Alert.alert('Erreur', 'Entre ton email ou numéro'); return; }
  if (!loginMdp.trim())   { Alert.alert('Erreur', 'Entre ton mot de passe'); return; }

  setLoading(true);
  try {
    const { data } = await authService.login(loginIdent.trim(), loginMdp);
    await setAuth({
      id: data.userId,
      nom: data.nom,
      email: data.email,
      scoreReputation: 0,
      nombreEchanges: 0,
    }, data.token);
    
    // ✅ Reset complet de la navigation
    router.dismissAll();
    router.replace('/(tabs)/accueil');
  } catch {
    Alert.alert('Erreur', 'Identifiant ou mot de passe incorrect');
  } finally { setLoading(false); }
};

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: '#0D1B2A' }}
      contentContainerStyle={s.container}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}>
      <StatusBar barStyle="light-content" backgroundColor="#0D1B2A" />

      {/* Glow déco */}
      <View style={s.glow} />

      {/* Logo */}
      <View style={s.logoRow}>
        <View style={s.logoBox}><Text style={s.logoIco}>⇄</Text></View>
        <Text style={s.logoTxt}>
          <Text style={{ color: COLORS.primary }}>Troc</Text>
          <Text style={{ color: '#fff' }}>Market</Text>
        </Text>
        <View style={s.secBadge}>
          <Text style={s.secTxt}>🔒 Sécurisé</Text>
        </View>
      </View>

      {/* Titre */}
      <Text style={s.overline}>BIENVENUE SUR TROCMARKET</Text>
      <Text style={s.title}>
        Rejoignez la communauté{'\n'}
        <Text style={{ color: COLORS.primary }}>d'échange locale</Text>
      </Text>
      <Text style={s.titleSub}>
        {onglet === 'inscription'
          ? 'Créez votre compte en quelques secondes.'
          : 'Connectez-vous pour continuer à troquer.'}
      </Text>

      {/* Onglets */}
      <View style={s.tabs}>
        {(['inscription', 'connexion'] as Onglet[]).map(o => (
          <TouchableOpacity key={o}
            style={[s.tab, onglet === o && s.tabActive]}
            onPress={() => setOnglet(o)}>
            <Text style={[s.tabTxt, onglet === o && s.tabTxtActive]}>
              {o === 'inscription' ? 'Inscription' : 'Connexion'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ── INSCRIPTION ── */}
      {onglet === 'inscription' && (
        <>
          {/* Nom */}
          <View style={s.field}>
            <Text style={s.label}>👤 NOM COMPLET</Text>
            <TextInput style={s.input}
              placeholder="Ex : Kouassi Jean-Baptiste"
              placeholderTextColor="#FFFFFF35"
              value={nom} onChangeText={setNom}
              autoCapitalize="words" />
          </View>

{/* Email ou téléphone */}
<View style={s.field}>
  <Text style={s.label}>📱 EMAIL OU NUMÉRO DE TÉLÉPHONE</Text>
  {isEmail(identifiant) ? (
    <TextInput style={s.input}
      placeholder="exemple@email.com"
      placeholderTextColor="#FFFFFF35"
      value={identifiant} onChangeText={setIdent}
      keyboardType="email-address"
      autoCapitalize="none" />
  ) : (
    <View style={s.phoneRow}>
      <View style={s.countryBtn}>
        <Text style={s.flag}>🇨🇲</Text>
        <Text style={s.code}>+237</Text>
      </View>
      <TextInput style={[s.input, { flex: 1 }]}
        placeholder="6XX XXX XXX"
        placeholderTextColor="#FFFFFF35"
        value={identifiant} onChangeText={setIdent}
        keyboardType="phone-pad" // CHANGÉ ICI pour avoir le pavé numérique
        autoCapitalize="none" />
    </View>
  )}
</View>

          {/* Mot de passe */}
          <View style={s.field}>
            <Text style={s.label}>🔒 MOT DE PASSE</Text>
            <View style={s.pwRow}>
              <TextInput style={[s.input, { flex: 1 }]}
                placeholder="Minimum 6 caractères"
                placeholderTextColor="#FFFFFF35"
                value={motdepasse} onChangeText={setMdp}
                secureTextEntry={!showMdp} />
              <TouchableOpacity style={s.eyeBtn} onPress={() => setShowMdp(!showMdp)}>
                <Text style={s.eyeTxt}>{showMdp ? '🙈' : '👁'}</Text>
              </TouchableOpacity>
            </View>
            {/* Indicateur force */}
            {motdepasse.length > 0 && (
              <View style={s.strengthRow}>
                {[1, 2, 3].map(i => (
                  <View key={i} style={[s.strengthBar, {
                    backgroundColor: motdepasse.length >= i * 4
                      ? i === 1 ? '#EF4444' : i === 2 ? '#F59E0B' : '#10B981'
                      : '#FFFFFF15'
                  }]} />
                ))}
                <Text style={s.strengthTxt}>
                  {motdepasse.length < 4 ? 'Faible' : motdepasse.length < 8 ? 'Moyen' : 'Fort'}
                </Text>
              </View>
            )}
          </View>

          {/* CGU */}
          <TouchableOpacity style={s.cguRow} onPress={() => setCgu(!cgu)}>
            <View style={[s.checkbox, cgu && { backgroundColor: COLORS.primary, borderColor: COLORS.primary }]}>
              {cgu && <Text style={{ color: '#fff', fontSize: 11, fontWeight: '800' }}>✓</Text>}
            </View>
            <Text style={s.cguTxt}>
              J'accepte les{' '}
              <Text style={{ color: COLORS.primary, fontWeight: '600' }}>Conditions d'utilisation</Text>
              {' '}et la{' '}
              <Text style={{ color: COLORS.primary, fontWeight: '600' }}>Politique de confidentialité</Text>
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[s.cta, loading && { opacity: 0.65 }]}
            onPress={doInscription} disabled={loading}>
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Text style={s.ctaTxt}>Créer mon compte →</Text>
            }
          </TouchableOpacity>
        </>
      )}

      {/* ── CONNEXION ── */}
      {onglet === 'connexion' && (
        <>
          <View style={s.field}>
            <Text style={s.label}>📱 EMAIL OU NUMÉRO DE TÉLÉPHONE</Text>
            <TextInput style={s.input}
              placeholder="email@exemple.com  ou  6XX XXX XXX"
              placeholderTextColor="#FFFFFF35"
              value={loginIdent} onChangeText={setLoginId}
              keyboardType="email-address"
              autoCapitalize="none" />
          </View>

          <View style={s.field}>
            <Text style={s.label}>🔒 MOT DE PASSE</Text>
            <View style={s.pwRow}>
              <TextInput style={[s.input, { flex: 1 }]}
                placeholder="Votre mot de passe"
                placeholderTextColor="#FFFFFF35"
                value={loginMdp} onChangeText={setLoginMdp}
                secureTextEntry={!showLoginMdp} />
              <TouchableOpacity style={s.eyeBtn} onPress={() => setShowLMdp(!showLoginMdp)}>
                <Text style={s.eyeTxt}>{showLoginMdp ? '🙈' : '👁'}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity style={s.forgotBtn}>
            <Text style={s.forgotTxt}>Mot de passe oublié ?</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[s.cta, loading && { opacity: 0.65 }]}
            onPress={doConnexion} disabled={loading}>
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Text style={s.ctaTxt}>Se connecter →</Text>
            }
          </TouchableOpacity>
        </>
      )}

      {/* Switch onglet */}
      <TouchableOpacity onPress={() => setOnglet(onglet === 'inscription' ? 'connexion' : 'inscription')}
        style={{ marginTop: 8 }}>
        <Text style={s.switchTxt}>
          {onglet === 'inscription' ? 'Déjà un compte ? ' : 'Pas encore de compte ? '}
          <Text style={{ color: COLORS.primary, fontWeight: '700' }}>
            {onglet === 'inscription' ? 'Se connecter' : "S'inscrire"}
          </Text>
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:    { padding: 24, paddingTop: 56, paddingBottom: 48 },
  glow:         { position: 'absolute', top: 50, right: -100, width: 260, height: 260, borderRadius: 130, backgroundColor: COLORS.primary + '14' },
  logoRow:      { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 28 },
  logoBox:      { width: 36, height: 36, borderRadius: 10, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  logoIco:      { color: '#fff', fontSize: 16, fontWeight: '900' },
  logoTxt:      { fontSize: 20, fontWeight: '800', flex: 1 },
  secBadge:     { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, backgroundColor: '#10B98118', borderWidth: 1, borderColor: '#10B98135' },
  secTxt:       { color: '#10B981', fontSize: 11, fontWeight: '600' },
  overline:     { fontSize: 11, color: COLORS.primary, fontWeight: '700', letterSpacing: 1.5, marginBottom: 6 },
  title:        { fontSize: 24, fontWeight: '800', color: '#fff', lineHeight: 32, marginBottom: 8 },
  titleSub:     { fontSize: 13, color: '#FFFFFF90', lineHeight: 19, marginBottom: 24 },
  tabs:         { flexDirection: 'row', backgroundColor: '#FFFFFF0E', borderRadius: 14, padding: 4, marginBottom: 24 },
  tab:          { flex: 1, paddingVertical: 11, borderRadius: 10, alignItems: 'center' },
  tabActive:    { backgroundColor: COLORS.primary },
  tabTxt:       { color: '#FFFFFF55', fontWeight: '600', fontSize: 14 },
  tabTxtActive: { color: '#fff', fontWeight: '800' },
  field:        { marginBottom: 16 },
  label:        { fontSize: 11, color: COLORS.primary, fontWeight: '700', letterSpacing: 1, marginBottom: 8 },
  input:        { backgroundColor: '#FFFFFF0C', borderWidth: 1, borderColor: '#FFFFFF1E', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14, fontSize: 15, color: '#fff' },
  hint:         { fontSize: 11, color: '#FFFFFF45', marginTop: 5, marginLeft: 4 },
  phoneRow:     { flexDirection: 'row', gap: 8 },
  countryBtn:   { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: '#FFFFFF0C', borderWidth: 1, borderColor: '#FFFFFF1E', borderRadius: 12, paddingHorizontal: 12 },
  flag:         { fontSize: 18 },
  code:         { color: '#fff', fontWeight: '700', fontSize: 13 },
  pwRow:        { flexDirection: 'row', gap: 8 },
  eyeBtn:       { width: 50, backgroundColor: '#FFFFFF0C', borderWidth: 1, borderColor: '#FFFFFF1E', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  eyeTxt:       { fontSize: 18 },
  strengthRow:  { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8 },
  strengthBar:  { flex: 1, height: 3, borderRadius: 2 },
  strengthTxt:  { fontSize: 10, color: '#FFFFFF60', minWidth: 36 },
  cguRow:       { flexDirection: 'row', gap: 10, marginBottom: 20, alignItems: 'flex-start' },
  checkbox:     { width: 20, height: 20, borderRadius: 6, borderWidth: 1.5, borderColor: '#FFFFFF30', alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  cguTxt:       { flex: 1, fontSize: 12, color: '#FFFFFF90', lineHeight: 18 },
  forgotBtn:    { alignSelf: 'flex-end', marginBottom: 20 },
  forgotTxt:    { color: COLORS.primary, fontSize: 13, fontWeight: '600' },
  cta:          { backgroundColor: COLORS.primary, borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginBottom: 16, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 10, elevation: 6 },
  ctaTxt:       { color: '#fff', fontSize: 16, fontWeight: '800' },
  switchTxt:    { color: '#FFFFFF55', fontSize: 13, textAlign: 'center' },
});