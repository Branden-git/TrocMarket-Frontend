import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView,
  TextInput, StatusBar, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { useAuthStore, ZoneInfo } from '../../store/authStore';
import { annonceService } from '../../services/api';
// Ajoute (si pas déjà là) :
import { useTheme } from '../../context/ThemeContext';

type ZoneType = 'campus' | 'quartier' | 'ville';

// Zones fixes Yaoundé — le nb d'objets est récupéré depuis l'API
const CAMPUS: Omit<ZoneInfo, 'type'>[] = [
  { id: 'uy1',       label: 'Université de Yaoundé I',   ville: 'Yaoundé', quartier: 'Ngoa-Ekellé' },
  { id: 'uy2',       label: 'Université de Yaoundé II',  ville: 'Soa',     quartier: 'Soa'         },
  { id: 'iric',      label: 'IRIC Yaoundé',              ville: 'Yaoundé', quartier: 'Bastos'      },
  { id: 'enam',      label: 'ENAM Yaoundé',              ville: 'Yaoundé', quartier: 'Centre'      },
  { id: 'polytec',   label: 'École Polytechnique',       ville: 'Yaoundé', quartier: 'Ngoa-Ekellé' },
];

const QUARTIERS: Omit<ZoneInfo, 'type'>[] = [
  { id: 'bastos',    label: 'Bastos',        ville: 'Yaoundé', quartier: 'Bastos'    },
  { id: 'melen',     label: 'Melen',         ville: 'Yaoundé', quartier: 'Melen'     },
  { id: 'mvog_mbi',  label: 'Mvog-Mbi',      ville: 'Yaoundé', quartier: 'Mvog-Mbi'  },
  { id: 'essos',     label: 'Essos',         ville: 'Yaoundé', quartier: 'Essos'     },
  { id: 'mendong',   label: 'Mendong',       ville: 'Yaoundé', quartier: 'Mendong'   },
  { id: 'nkoldongo', label: 'Nkoldongo',     ville: 'Yaoundé', quartier: 'Nkoldongo' },
  { id: 'ngousso',   label: 'Ngousso',       ville: 'Yaoundé', quartier: 'Ngousso'   },
  { id: 'biyem_assi',label: 'Biyem-Assi',    ville: 'Yaoundé', quartier: 'Biyem-Assi'},
  { id: 'ekounou',   label: 'Ekounou',       ville: 'Yaoundé', quartier: 'Ekounou'   },
  { id: 'mimboman',  label: 'Mimboman',      ville: 'Yaoundé', quartier: 'Mimboman'  },
];

const VILLES: Omit<ZoneInfo, 'type'>[] = [
  { id: 'yaounde',   label: 'Yaoundé',    ville: 'Yaoundé'    },
  { id: 'douala',    label: 'Douala',     ville: 'Douala'     },
  { id: 'bafoussam', label: 'Bafoussam',  ville: 'Bafoussam'  },
  { id: 'garoua',    label: 'Garoua',     ville: 'Garoua'     },
  { id: 'maroua',    label: 'Maroua',     ville: 'Maroua'     },
  { id: 'bertoua',   label: 'Bertoua',    ville: 'Bertoua'    },
  { id: 'bamenda',   label: 'Bamenda',    ville: 'Bamenda'    },
  { id: 'buea',      label: 'Buea',       ville: 'Buea'       },
];

export default function Zone() {
  const { theme } = useTheme();
  const C = theme.colors;
  const s = makeStyles(C);
  const [zoneType, setZoneType] = useState<ZoneType>('campus');
  const [selectedId, setSelectedId] = useState<string>('');
  const [search, setSearch] = useState('');
  const { setZone, zone: zoneSauvegardee } = useAuthStore();

  // Nombre réel d'annonces par ville via l'API
  // Remplace le bloc useQuery existant dans Zone.tsx
const { data: statsData } = useQuery({
  queryKey: ['annonces-stats', zoneType],
  queryFn: async () => {
    // On récupère la liste actuelle (Campus, Quartiers ou Villes)
    const currentList = getList();
    
    const results = await Promise.all(
      currentList.map(async (z) => {
        try {
          const params: any = { ville: z.ville };
          // Si c'est un campus ou quartier, on ajoute le filtre quartier
          if (z.quartier) {
            params.quartier = z.quartier;
          }
          
          const r = await annonceService.getAll(params);
          return {
            id: z.id,
            count: r.data?.totalElements ?? 0,
          };
        } catch (e) {
          return { id: z.id, count: 0 };
        }
      })
    );
    // On crée un dictionnaire { 'uy1': 15, 'bastos': 42, ... }
    return Object.fromEntries(results.map(r => [r.id, r.count]));
  },
});

  const getList = () => {
    if (zoneType === 'campus')   return CAMPUS;
    if (zoneType === 'quartier') return QUARTIERS;
    return VILLES;
  };

  const filtered = getList().filter(z =>
    z.label.toLowerCase().includes(search.toLowerCase())
  );

  const getObjetsCount = (z: Omit<ZoneInfo, 'type'>) => {
  // On cherche par ID car statsData contient maintenant { 'uy1': X, 'melen': Y }
  const count = statsData?.[z.id] ?? 0;
  return count > 0 
    ? (count >= 1000 ? `${(count / 1000).toFixed(1)}k` : String(count)) 
    : '0'; // Affiche 0 au lieu de "—" pour montrer que c'est réel
  };

  const selectedZone = getList().find(z => z.id === selectedId);

  const handleValider = async () => {
    if (!selectedZone) return;
    const zone: ZoneInfo = { ...selectedZone, type: zoneType };
    await setZone(zone);
    router.replace('/(tabs)/accueil');
  };

  const TABS: { id: ZoneType; label: string; emoji: string }[] = [
    { id: 'campus',   label: 'Campus',    emoji: '🎓' },
    { id: 'quartier', label: 'Quartiers', emoji: '🏘' },
    { id: 'ville',    label: 'Villes',    emoji: '🌆' },
  ];

  return (
    <View style={s.root}>
      <StatusBar barStyle="dark-content" backgroundColor={C.background} />

      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => router.back()} style={s.backBtn}>
          <Text style={s.backIco}>←</Text>
        </TouchableOpacity>
        <View style={s.logoRow}>
          <View style={s.logoBox}><Text style={s.logoIco}>⇄</Text></View>
          <Text style={s.logoTxt}>
            <Text style={{ color: C.primary }}>Troc</Text>
            <Text style={{ color: C.text }}>Market</Text>
          </Text>
        </View>
        {zoneSauvegardee && (
          <View style={s.locBadge}>
            <Text style={s.locTxt}>📍 {zoneSauvegardee.label.split(' ')[0]}</Text>
          </View>
        )}
      </View>

      {/* Titre */}
      <View style={s.titleWrap}>
        <Text style={s.step}>ÉTAPE 2 SUR 2</Text>
        <Text style={s.title}>
          Choisissez votre{'\n'}
          <Text style={{ color: C.primary }}>zone d'échange</Text>
        </Text>
        <Text style={s.sub}>Les annonces affichées seront celles de votre zone.</Text>
      </View>

      {/* Recherche */}
      <View style={s.searchRow}>
        <TextInput style={s.searchInput}
          placeholder="Rechercher un campus ou quartier..."
          placeholderTextColor={C.textMuted}
          value={search} onChangeText={setSearch} />
        <Text style={{ padding: 4 }}>📍</Text>
      </View>

      {/* Onglets */}
      <View style={s.typeTabs}>
        {TABS.map(t => (
          <TouchableOpacity key={t.id}
            style={[s.typeTab, zoneType === t.id && s.typeTabActive]}
            onPress={() => { setZoneType(t.id); setSelectedId(''); }}>
            <Text style={[s.typeTabTxt, zoneType === t.id && s.typeTabTxtActive]}>
              {t.emoji} {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={s.listHeader}>● ZONES DISPONIBLES</Text>

      {/* Liste */}
      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 12 }}>
        {filtered.map(zone => {
          const active  = selectedId === zone.id;
          const objets  = getObjetsCount(zone);
          const sousTxt = zoneType === 'campus'
            ? zone.quartier ?? zone.ville
            : zoneType === 'quartier'
              ? `${zone.ville}`
              : 'Toute la ville';
          return (
            <TouchableOpacity key={zone.id}
              style={[s.zoneCard, active && s.zoneCardActive]}
              onPress={() => setSelectedId(active ? '' : zone.id)}>
              <View style={[s.zoneIcon, active && { backgroundColor: C.primaryLight }]}>
                <Text style={{ fontSize: 20 }}>
                  {zoneType === 'campus' ? '🎓' : zoneType === 'quartier' ? '🏘' : '🌆'}
                </Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[s.zoneName, active && { color: C.primary }]} numberOfLines={1}>
                  {zone.label}
                </Text>
                <Text style={s.zoneInfo}>
                  {sousTxt} · <Text style={{ color: objets !== '—' ? C.primary : C.textMuted, fontWeight: '700' }}>{objets}</Text> annonces
                </Text>
              </View>
              {active && (
                <View style={s.checkCircle}>
                  <Text style={{ color: '#fff', fontSize: 12, fontWeight: '800' }}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Barre zone sélectionnée */}
      {selectedZone && (
        <View style={s.selectedBar}>
          <Text style={s.selectedPin}>📍</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.selectedLbl}>Zone sélectionnée</Text>
            <Text style={s.selectedName}>{selectedZone.label}</Text>
          </View>
          <View style={s.selectedCount}>
            <Text style={s.selectedCountTxt}>{getObjetsCount(selectedZone)} annonces</Text>
          </View>
        </View>
      )}

      {/* CTA */}
      <TouchableOpacity
        style={[s.cta, !selectedId && { opacity: 0.5 }]}
        onPress={handleValider}
        disabled={!selectedId}>
        <Text style={s.ctaTxt}>🏪 Explorer le Marché →</Text>
      </TouchableOpacity>
      <Text style={s.hint}>⟳ Vous pourrez changer de zone à tout moment</Text>
    </View>
  );
}

function makeStyles(C: any) {
  return StyleSheet.create({ 
  root:            { flex: 1, backgroundColor: C.background },
  header:          { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 16 },
  backBtn:         { width: 36, height: 36, borderRadius: 10, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  backIco:         { color: C.text, fontSize: 18 },
  logoRow:         { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 },
  logoBox:         { width: 28, height: 28, borderRadius: 8, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' },
  logoIco:         { color: '#fff', fontSize: 13, fontWeight: '900' },
  logoTxt:         { fontSize: 16, fontWeight: '800' },
  locBadge:        { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, backgroundColor: C.primaryLight, borderWidth: 1, borderColor: C.primary + '40' },
  locTxt:          { color: C.primary, fontSize: 12, fontWeight: '600' },
  titleWrap:       { paddingHorizontal: 16, marginBottom: 14 },
  step:            { fontSize: 11, color: C.primary, fontWeight: '700', letterSpacing: 1.5, marginBottom: 6 },
  title:           { fontSize: 24, fontWeight: '800', color: C.text, lineHeight: 32, marginBottom: 5 },
  sub:             { fontSize: 13, color: C.textMuted },
  searchRow:       { flexDirection: 'row', marginHorizontal: 16, marginBottom: 12, backgroundColor: C.surface, borderRadius: 12, borderWidth: 1, borderColor: C.border, paddingHorizontal: 14, alignItems: 'center' },
  searchInput:     { flex: 1, paddingVertical: 13, fontSize: 14, color: C.text },
  typeTabs:        { flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 12 },
  typeTab:         { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: C.surface, borderWidth: 1.5, borderColor: C.border },
  typeTabActive:   { backgroundColor: C.primary, borderColor: C.primary },
  typeTabTxt:      { color: C.textMuted, fontSize: 13, fontWeight: '500' },
  typeTabTxtActive:{ color: '#fff', fontWeight: '700' },
  listHeader:      { fontSize: 11, color: C.primary, fontWeight: '700', letterSpacing: 1, paddingHorizontal: 16, marginBottom: 10 },
  zoneCard:        { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.surface, borderRadius: 14, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: C.border },
  zoneCardActive:  { borderColor: C.primary, backgroundColor: C.primaryLight + '30' },
  zoneIcon:        { width: 44, height: 44, borderRadius: 12, backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
  zoneName:        { color: C.text, fontWeight: '700', fontSize: 14, marginBottom: 3 },
  zoneInfo:        { color: C.textMuted, fontSize: 12 },
  checkCircle:     { width: 26, height: 26, borderRadius: 13, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' },
  selectedBar:     { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 16, marginBottom: 10, backgroundColor: C.primaryLight, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.primary + '40' },
  selectedPin:     { fontSize: 18 },
  selectedLbl:     { fontSize: 11, color: C.primary, fontWeight: '600' },
  selectedName:    { fontSize: 14, color: C.text, fontWeight: '700' },
  selectedCount:   { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, backgroundColor: C.primary + '20' },
  selectedCountTxt:{ fontSize: 12, color: C.primary, fontWeight: '700' },
  cta:             { marginHorizontal: 16, marginBottom: 6, backgroundColor: C.primary, borderRadius: 14, paddingVertical: 16, alignItems: 'center', shadowColor: C.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 10, elevation: 6 },
  ctaTxt:          { color: '#fff', fontSize: 16, fontWeight: '800' },
  hint:            { textAlign: 'center', color: C.textMuted, fontSize: 11, paddingBottom: 20 },
});
}