import { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Alert, StatusBar } from 'react-native';
import { router } from 'expo-router';
import { useAuthStore } from '../../store/authStore';
import { authService } from '../../services/api';
import { COLORS } from '../../constants';
import Icon from '@/components/Icon'; 

export default function Connexion() {
  const [telephone, setTel]   = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp]         = useState(['', '', '', '']);
  const [loading, setLoading] = useState(false);
  const refs = [useRef<TextInput>(null), useRef<TextInput>(null), useRef<TextInput>(null), useRef<TextInput>(null)];
  const { setAuth } = useAuthStore();

  const sendOtp = () => {
    if (!telephone.trim()) { Alert.alert('Erreur', 'Entre ton numéro'); return; }
    setOtpSent(true);
  };

  const handleOtp = (val: string, i: number) => {
    const next = [...otp];
    next[i] = val;
    setOtp(next);
    if (val && i < 3) refs[i + 1].current?.focus();
  };

  const doConnexion = async () => {
    const code = otp.join('');
    if (code.length < 4) { Alert.alert('Erreur', 'Entre le code OTP complet'); return; }
    setLoading(true);
    try {
      const tel   = telephone.replace(/\s/g, '');
      const email = `${tel}@trocmarket.cm`;
      const { data } = await authService.login(email, tel);
      await setAuth({ id: data.userId, nom: data.nom, email: data.email, scoreReputation: 0, nombreEchanges: 0 }, data.token);
      router.replace('/(tabs)/accueil');
    } catch {
      Alert.alert('Erreur', 'Code incorrect ou compte non trouvé');
    } finally { setLoading(false); }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#0D1B2A' }}
      contentContainerStyle={s.container}
      keyboardShouldPersistTaps="handled">
      <StatusBar barStyle="light-content" backgroundColor="#0D1B2A" />
      <View style={s.glow} />

      {/* Logo */}
      <View style={s.logoRow}>
        <View style={s.logoBox}><Text style={s.logoIco}>⇄</Text></View>
        <Text style={s.logoTxt}><Text style={{ color: COLORS.primary }}>Troc</Text><Text style={{ color: '#fff' }}>Mobile</Text></Text>
        <View style={s.secBadge}><Text style={s.secTxt}><Icon name="bx-lock" size={10} color="#10B981" /> Sécurisé</Text></View>
      </View>

      <Text style={s.overline}>BIENVENUE SUR TROCMOBILE</Text>
      <Text style={s.title}>Rejoignez la communauté{'\n'}<Text style={{ color: COLORS.primary }}>d'échange locale</Text></Text>
      <Text style={s.titleSub}>Entrez votre nom et numéro pour commencer à troquer près de chez vous.</Text>

      {/* Onglets */}
      <View style={s.tabs}>
        <TouchableOpacity style={s.tab} onPress={() => router.replace('/(auth)/inscription')}>
          <Text style={s.tabTxt}>Inscription</Text>
        </TouchableOpacity>
        <View style={[s.tab, s.tabActive]}>
          <Text style={s.tabTxtActive}>Connexion</Text>
        </View>
      </View>

      {/* Téléphone */}
      <View style={s.field}>
        <View style={s.phoneRow}>
          <View style={s.countryBtn}>
            <Text style={s.countryFlag}>🇨🇲</Text>
            <Text style={s.countryCode}>+237</Text>
            <Text style={s.countryChev}>▼</Text>
          </View>
          <TextInput style={[s.input, { flex: 1 }]}
            placeholder="6XX XXX XXX"
            placeholderTextColor="#FFFFFF35"
            value={telephone} onChangeText={setTel}
            keyboardType="phone-pad" maxLength={9}
            editable={!otpSent} />
        </View>
        <Text style={s.fieldHint}>Votre numéro enregistré sur TrocMobile</Text>
      </View>

      {/* OTP */}
      {otpSent && (
        <View style={s.field}>
          <View style={s.otpHeader}>
            <Text style={s.fieldLabel}><Icon name="bx-key" size={10} color="#b97b10" /> CODE OTP</Text>
            <TouchableOpacity onPress={() => setOtpSent(false)}>
              <Text style={s.resendTxt}>Renvoyer le code</Text>
            </TouchableOpacity>
          </View>
          <View style={s.otpRow}>
            {otp.map((v, i) => (
              <TextInput key={i} ref={refs[i]}
                style={s.otpBox}
                value={v} onChangeText={val => handleOtp(val.slice(-1), i)}
                keyboardType="number-pad" maxLength={1}
                textAlign="center" />
            ))}
          </View>
          <Text style={s.fieldHint}><Icon name="bx-message" size={10} color="#b97b10" /> Un SMS avec votre code a été envoyé au +237 6XX XXX XXX</Text>
        </View>
      )}

      {/* Séparateur social */}
      <View style={s.orRow}>
        <View style={s.orLine} /><Text style={s.orTxt}>ou continuer avec</Text><View style={s.orLine} />
      </View>

      <View style={s.socialRow}>
        <TouchableOpacity style={s.socialBtn}>
          <Text style={[s.socialIco, { color: '#EA4335' }]}>G</Text>
          <Text style={s.socialTxt}>Google</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.socialBtn}>
          <Text style={[s.socialIco, { color: '#1877F2' }]}>f</Text>
          <Text style={s.socialTxt}>Facebook</Text>
        </TouchableOpacity>
      </View>

      <View style={s.secRow}>
        {[
          { label: 'Données protégées', icon: 'bx-shield-quarter' },
          { label: 'Connexion sécurisée', icon: 'bx-lock-alt' },
          { label: 'Privé', icon: 'bx-user-check' }
        ].map((item, i) => (
      <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
        <Icon name={item.icon} size={14} color="#FFFFFF45" />
        <Text style={s.secItem}>{item.label}</Text>
      </View>
      ))}
      </View>

      {/* CTA */}
      <TouchableOpacity style={[s.cta, loading && { opacity: 0.65 }]}
        onPress={otpSent ? doConnexion : sendOtp} disabled={loading}>
        <Text style={s.ctaTxt}>
          {loading ? 'Vérification...' : otpSent ? 'Se connecter →' : 'Envoyer le code SMS →'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => router.replace('/(auth)/inscription')}>
        <Text style={s.switchTxt}>Pas encore de compte ? <Text style={{ color: COLORS.primary, fontWeight: '700' }}>S'inscrire</Text></Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { padding: 24, paddingTop: 52, paddingBottom: 40 },
  glow:      { position: 'absolute', top: 50, right: -100, width: 260, height: 260, borderRadius: 130, backgroundColor: COLORS.primary + '14' },
  logoRow:   { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 24 },
  logoBox:   { width: 36, height: 36, borderRadius: 10, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  logoIco:   { color: '#fff', fontSize: 16, fontWeight: '900' },
  logoTxt:   { fontSize: 20, fontWeight: '800', flex: 1 },
  secBadge:  { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, backgroundColor: '#10B98118', borderWidth: 1, borderColor: '#10B98135' },
  secTxt:    { color: '#10B981', fontSize: 11, fontWeight: '600' },
  overline:  { fontSize: 11, color: COLORS.primary, fontWeight: '700', letterSpacing: 1.5, marginBottom: 6 },
  title:     { fontSize: 24, fontWeight: '800', color: '#fff', lineHeight: 32, marginBottom: 8 },
  titleSub:  { fontSize: 13, color: '#FFFFFF90', lineHeight: 19, marginBottom: 22 },
  tabs:      { flexDirection: 'row', backgroundColor: '#FFFFFF0E', borderRadius: 14, padding: 4, marginBottom: 22 },
  tab:       { flex: 1, paddingVertical: 11, borderRadius: 10, alignItems: 'center' },
  tabActive: { backgroundColor: COLORS.primary },
  tabTxt:    { color: '#FFFFFF55', fontWeight: '600', fontSize: 14 },
  tabTxtActive: { color: '#fff', fontWeight: '800' },
  field:     { marginBottom: 14 },
  fieldLabel: { fontSize: 11, color: COLORS.primary, fontWeight: '700', letterSpacing: 1, marginBottom: 7 },
  input:     { backgroundColor: '#FFFFFF0C', borderWidth: 1, borderColor: '#FFFFFF1E', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14, fontSize: 15, color: '#fff' },
  fieldHint: { fontSize: 11, color: '#FFFFFF45', marginTop: 4, marginLeft: 4 },
  phoneRow:  { flexDirection: 'row', gap: 8 },
  countryBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: '#FFFFFF0C', borderWidth: 1, borderColor: '#FFFFFF1E', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 14 },
  countryFlag: { fontSize: 18 },
  countryCode: { color: '#fff', fontWeight: '700', fontSize: 13 },
  countryChev: { color: '#FFFFFF55', fontSize: 10 },
  otpHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  resendTxt: { color: COLORS.primary, fontSize: 13, fontWeight: '600' },
  otpRow:    { flexDirection: 'row', gap: 12, justifyContent: 'center' },
  otpBox:    { width: 58, height: 64, backgroundColor: '#FFFFFF0C', borderWidth: 1.5, borderColor: '#FFFFFF30', borderRadius: 14, fontSize: 24, fontWeight: '800', color: '#fff' },
  orRow:     { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 13 },
  orLine:    { flex: 1, height: 1, backgroundColor: '#FFFFFF14' },
  orTxt:     { color: '#FFFFFF45', fontSize: 12 },
  socialRow: { flexDirection: 'row', gap: 12, marginBottom: 18 },
  socialBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#FFFFFF0C', borderWidth: 1, borderColor: '#FFFFFF1E', borderRadius: 12, paddingVertical: 13 },
  socialIco: { fontSize: 16, fontWeight: '800' },
  socialTxt: { color: '#fff', fontSize: 14, fontWeight: '600' },
  secRow:    { flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'center', marginBottom: 22 },
  secItem:   { color: '#FFFFFF45', fontSize: 11 },
  cta:       { backgroundColor: COLORS.primary, borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginBottom: 14, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 10, elevation: 6 },
  ctaTxt:    { color: '#fff', fontSize: 16, fontWeight: '800' },
  switchTxt: { color: '#FFFFFF55', fontSize: 13, textAlign: 'center' },
});