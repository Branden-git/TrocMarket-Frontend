import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Dimensions, StatusBar } from 'react-native';
import { router } from 'expo-router';
import { COLORS } from '../../constants';
import Icon from '@/components/Icon'; 

const { width } = Dimensions.get('window');

const SLIDES = [
  {
    key: 'TROC',
    badge: 'POPULAIRE', badgeBg: COLORS.primary + '25', badgeColor: COLORS.primary,
    icon: '⇄', iconBg: COLORS.primary + '22',
    title: 'Le Troc', subtitle: 'Échange sans argent',
    desc: "Proposez votre objet et choisissez ce que vous voulez en échange. Négociez directement dans le chat, sans débourser un franc !",
    features: ['Sans argent', 'Chat intégré', 'Contre-offres', 'Géolocalisé'],
    items: [{ emoji: '📱', label: 'iPhone' }, { emoji: '🚲', label: 'Vélo' }],
    result: '🤝 Accord trouvé !', resultColor: COLORS.primary,
    btnLabel: 'Commencer avec le Troc →', btnColor: COLORS.primary,
    tabLabel: '⇄ Troc',
  },
  {
    key: 'DON',
    badge: 'SOLIDAIRE', badgeBg: COLORS.don + '25', badgeColor: COLORS.don,
    icon: '♡', iconBg: COLORS.don + '22',
    title: 'Le Don', subtitle: 'Offrez gratuitement',
    desc: "Donnez une seconde vie à vos objets en les offrant à votre communauté. Gagnez des badges de solidarité et construisez votre réputation !",
    features: ['100% gratuit', 'Badges gagnés', 'Karma +', 'Proche de vous'],
    items: [{ emoji: '👕', label: 'Vêtements' }, { emoji: '📚', label: 'Livres' }],
    result: '⭐ Donateur du mois !', resultColor: COLORS.don,
    btnLabel: 'Commencer à Donner →', btnColor: COLORS.don,
    tabLabel: '♡ Don',
  },
  {
    key: 'VENTE',
    badge: 'PREMIUM', badgeBg: COLORS.premium + '25', badgeColor: COLORS.premium,
    icon: '🏷', iconBg: COLORS.premium + '22',
    title: 'La Vente', subtitle: 'Vendez et encaissez',
    desc: "Vendez vos objets en fixant votre prix. Encaissez directement via MTN Mobile Money ou Orange Money. Simple et sécurisé !",
    features: ['Mobile Money', 'Prix libre', 'Wallet intégré', 'Paiement sécurisé'],
    items: [{ emoji: '📺', label: 'TV\n25 000 F' }, { emoji: '🛋️', label: 'Canapé\n15 000 F' }],
    result: '📱 Paiement Mobile Money', resultColor: COLORS.premium,
    btnLabel: 'Commencer à Vendre →', btnColor: COLORS.premium,
    tabLabel: '🏷 Vente',
  },
];

export default function Onboarding() {
  const [idx, setIdx] = useState(0);
  const slide = SLIDES[idx];

  const next = () => {
    if (idx < SLIDES.length - 1) setIdx(idx + 1);
    else router.replace('/(auth)/inscription');
  };

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor="#0D1B2A" />
      <View style={s.glow} />

      {/* Header */}
      <View style={s.header}>
        <View style={s.logoRow}>
          <View style={s.logoBox}><Text style={s.logoIcon}>⇄</Text></View>
          <Text style={s.logoText}>
            <Text style={{ color: COLORS.primary }}>Troc</Text>
            <Text style={{ color: '#fff' }}>Market</Text>
          </Text>
        </View>
        <TouchableOpacity onPress={() => router.replace('/(auth)/inscription')} style={s.skipBtn}>
          <Text style={s.skipText}>Passer ›</Text>
        </TouchableOpacity>
      </View>

      {/* Titre */}
      <Text style={s.overline}>DÉCOUVREZ COMMENT ÇA MARCHE</Text>
      <Text style={s.mainTitle}>
        3 façons d'échanger{'\n'}
        <Text style={{ color: COLORS.primary }}>près de chez vous</Text>
      </Text>

      {/* Onglets */}
      <View style={s.tabs}>
        {SLIDES.map((sl, i) => (
          <TouchableOpacity key={i} onPress={() => setIdx(i)}
            style={[s.tab, idx === i && { backgroundColor: '#FFFFFF1A', borderColor: '#FFFFFF35' }]}>
            <Text style={[s.tabText, idx === i && { color: '#fff', fontWeight: '700' }]}>{sl.tabLabel}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Illustration */}
      <View style={s.illus}>
        <View style={s.illuItem}>
          <View style={s.illuBox}><Text style={{ fontSize: 26 }}>{slide.items[0].emoji}</Text></View>
          <Text style={s.illuLabel}>{slide.items[0].label}</Text>
        </View>
        <View style={s.illuMid}>
          <View style={[s.illuSwap, { borderColor: slide.btnColor + '50', backgroundColor: slide.btnColor + '18' }]}>
            <Text style={{ color: slide.btnColor, fontSize: 20, fontWeight: '800' }}>⇄</Text>
          </View>
          <View style={[s.illuResult, { backgroundColor: slide.resultColor + '20', borderColor: slide.resultColor + '40' }]}>
            <Text style={[s.illuResultText, { color: slide.resultColor }]}>{slide.result}</Text>
          </View>
        </View>
        <View style={s.illuItem}>
          <View style={s.illuBox}><Text style={{ fontSize: 26 }}>{slide.items[1].emoji}</Text></View>
          <Text style={s.illuLabel}>{slide.items[1].label}</Text>
        </View>
      </View>

      {/* Carte info */}
      <View style={s.card}>
        <View style={s.cardHeader}>
          <View style={[s.cardIconBox, { backgroundColor: slide.iconBg }]}>
            <Text style={{ fontSize: 20 }}>{slide.icon}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <View style={s.cardTitleRow}>
              <Text style={s.cardTitle}>{slide.title}</Text>
              <View style={[s.badge, { backgroundColor: slide.badgeBg }]}>
                <Text style={[s.badgeText, { color: slide.badgeColor }]}>{slide.badge}</Text>
              </View>
            </View>
            <Text style={s.cardSub}>{slide.subtitle}</Text>
          </View>
        </View>
        <Text style={s.cardDesc}>{slide.desc}</Text>
        <View style={s.features}>
          {slide.features.map((f, i) => (
            <View key={i} style={s.feature}>
              <Text style={[s.featureCheck, { color: slide.btnColor }]}>✓</Text>
              <Text style={s.featureText}>{f}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Dots */}
      <View style={s.dots}>
        {SLIDES.map((_, i) => (
          <View key={i} style={[s.dot, idx === i && [s.dotActive, { backgroundColor: slide.btnColor }]]} />
        ))}
      </View>

      {/* CTA */}
      <TouchableOpacity style={[s.cta, { backgroundColor: slide.btnColor }]} onPress={next}>
        <Text style={s.ctaText}>{slide.btnLabel}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => router.replace('/(auth)/connexion')}>
        <Text style={s.loginLink}>Déjà un compte ? <Text style={{ color: COLORS.primary, fontWeight: '700' }}>Se connecter</Text></Text>
      </TouchableOpacity>
    </View>
  );
}

const s = StyleSheet.create({
  root:    { flex: 1, backgroundColor: '#0D1B2A', paddingHorizontal: 20, paddingTop: 52 },
  glow:    { position: 'absolute', top: 80, right: -90, width: 220, height: 220, borderRadius: 110, backgroundColor: COLORS.primary + '18' },
  header:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  logoBox: { width: 34, height: 34, borderRadius: 9, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  logoIcon: { color: '#fff', fontSize: 16, fontWeight: '800' },
  logoText: { fontSize: 18, fontWeight: '800' },
  skipBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1, borderColor: '#FFFFFF25' },
  skipText: { color: '#FFFFFF80', fontSize: 13 },
  overline: { fontSize: 11, color: COLORS.primary, fontWeight: '700', letterSpacing: 1.5, marginBottom: 6 },
  mainTitle: { fontSize: 23, fontWeight: '800', color: '#fff', lineHeight: 31, marginBottom: 16 },
  tabs:    { flexDirection: 'row', gap: 8, marginBottom: 18 },
  tab:     { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: '#FFFFFF18' },
  tabText: { color: '#FFFFFF55', fontSize: 13 },
  illus:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, paddingHorizontal: 4 },
  illuItem: { alignItems: 'center', gap: 6 },
  illuBox: { width: 58, height: 58, borderRadius: 14, backgroundColor: '#FFFFFF0E', borderWidth: 1, borderColor: '#FFFFFF18', alignItems: 'center', justifyContent: 'center' },
  illuLabel: { color: '#FFFFFF80', fontSize: 11, textAlign: 'center' },
  illuMid: { flex: 1, alignItems: 'center', gap: 8 },
  illuSwap: { width: 46, height: 46, borderRadius: 23, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  illuResult: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, borderWidth: 1 },
  illuResultText: { fontSize: 11, fontWeight: '700' },
  card:    { backgroundColor: '#FFFFFF0C', borderRadius: 16, borderWidth: 1, borderColor: '#FFFFFF14', padding: 14, marginBottom: 14 },
  cardHeader: { flexDirection: 'row', gap: 10, marginBottom: 8 },
  cardIconBox: { width: 42, height: 42, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  cardTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 2 },
  cardTitle: { fontSize: 17, fontWeight: '800', color: '#fff' },
  badge:   { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  badgeText: { fontSize: 10, fontWeight: '800' },
  cardSub: { fontSize: 12, color: '#FFFFFF90' },
  cardDesc: { fontSize: 13, color: '#FFFFFFD0', lineHeight: 19, marginBottom: 10 },
  features: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  feature:  { flexDirection: 'row', alignItems: 'center', gap: 4, width: '47%' },
  featureCheck: { fontSize: 12, fontWeight: '800' },
  featureText:  { color: '#FFFFFFB0', fontSize: 12 },
  dots:    { flexDirection: 'row', justifyContent: 'center', gap: 6, marginBottom: 14 },
  dot:     { width: 6, height: 6, borderRadius: 3, backgroundColor: '#FFFFFF25' },
  dotActive: { width: 20 },
  cta:     { borderRadius: 14, paddingVertical: 15, alignItems: 'center', marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.25, shadowRadius: 8, elevation: 5 },
  ctaText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  loginLink: { color: '#FFFFFF55', fontSize: 13, textAlign: 'center', paddingBottom: 16 },
});