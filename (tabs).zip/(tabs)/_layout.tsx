import { Tabs } from 'expo-router';
import { View, Text } from 'react-native';
import { TABS_CONFIG } from '../../constants';
import { useTheme } from '../../context/ThemeContext';

export default function TabsLayout() {
  const { theme } = useTheme();
  const C = theme.colors;

  return (
    <Tabs screenOptions={({ route }) => ({
      headerShown: false,
      tabBarActiveTintColor: C.primary,
      tabBarInactiveTintColor: C.textMuted,
      tabBarStyle: {
        backgroundColor: C.surface,
        borderTopWidth: 1,
        borderTopColor: C.border,
        height: 64,
        paddingBottom: 8,
        paddingTop: 6,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -3 },
        shadowOpacity: 0.06,
        shadowRadius: 12,
        elevation: 12,
      },
      tabBarLabelStyle: { fontSize: 10, fontWeight: '600', marginTop: 1 },
      tabBarIcon: ({ focused }) => {
        const tab = TABS_CONFIG.find(t => t.name === route.name);
        return (
          <View style={[
            { width: 34, height: 26, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
            focused && { backgroundColor: C.primaryLight },
          ]}>
            <Text style={{ fontSize: 17 }}>{tab?.emoji}</Text>
          </View>
        );
      },
    })}>
      <Tabs.Screen name="accueil"  options={{ title: 'Marché'   }} />
      <Tabs.Screen name="explorer" options={{ title: 'Explorer' }} />
      <Tabs.Screen name="messages" options={{ title: 'Messages' }} />
      <Tabs.Screen name="profil"   options={{ title: 'Profil'   }} />
    </Tabs>
  );
}