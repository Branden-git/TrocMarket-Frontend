import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList,
  TextInput, ActivityIndicator, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useQuery } from '@tanstack/react-query';
import { router } from 'expo-router';
import { chatService } from '../../services/api';
import { TYPE_CONFIG } from '../../constants';
import { useTheme } from '../../context/ThemeContext';
// Dans le composant :
import { useAuthStore } from '../../store/authStore';

type FilterType   = 'Tout' | 'Troc' | 'Vente' | 'Don';
type StatusFilter = 'Tous' | 'En attente' | 'Acceptées' | 'Contre-offres';

const STATUT_CONFIG: Record<string, { label: string; bg: string; color: string }> = {
  EN_ATTENTE:   { label: '⏳ Réponse attendue',  bg: '#FEF3C7', color: '#D97706' },
  CONTRE_OFFRE: { label: '↩ Contre-offre reçue', bg: '#EDE9FE', color: '#7C3AED' },
  A_EXAMINER:   { label: '🔍 À examiner',         bg: '#EFF6FF', color: '#3B82F6' },
  ACCEPTEE:     { label: '✅ Paiement confirmé',  bg: '#D1FAE5', color: '#10B981' },
  ANNULEE:      { label: '❌ Accord annulé',       bg: '#FEE2E2', color: '#EF4444' },
  INACTIF:      { label: '⬤ Inactif',             bg: '#F3F4F6', color: '#9CA3AF' },
  ACTIVE:       { label: '',                       bg: 'transparent', color: 'transparent' },
};

export default function Messages() {
  const { theme } = useTheme();
  const C = theme.colors;
  const s = makeStyles(C);
  const [search, setSearch]         = useState('');
  const [typeFilter, setTypeFilter] = useState<FilterType>('Tout');
  const [statusFilter, setStatus]   = useState<StatusFilter>('Tous');
  const { user } = useAuthStore();

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['conversations'],
    queryFn: () => chatService.getConversations().then(r => r.data),
    refetchInterval: 10000, // rafraîchit toutes les 10s
  });

  const conversations: any[] = Array.isArray(data) ? data : (data as any)?.content ?? [];

  const filtered = conversations.filter((c: any) => {
    const titre    = c.annonce?.titre ?? '';
    const partner  = c.participants?.find((p: any) => p.id !== user?.id)?.nom ?? '';
    const partnerNom = c.participants?.find((p: any) => p.id !== user?.id)?.nom
    ?? (c.initiateur?.id !== user?.id ? c.initiateur?.nom : c.destinataire?.nom) ?? '';
    if (search && !titre.toLowerCase().includes(search.toLowerCase()) &&
    !partnerNom.toLowerCase().includes(search.toLowerCase())) return false;
    if (typeFilter !== 'Tout' && c.annonce?.type !== typeFilter.toUpperCase()) return false;
    if (statusFilter === 'En attente'   && c.statut !== 'EN_ATTENTE')   return false;
    if (statusFilter === 'Acceptées'    && c.statut !== 'ACCEPTEE')     return false;
    if (statusFilter === 'Contre-offres' && c.statut !== 'CONTRE_OFFRE') return false;
    return true;
  });

  const nonLusTotal = filtered.reduce((s: number, c: any) => s + (c.nonLus ?? 0), 0);
  const enAttente   = filtered.filter((c: any) =>
    c.statut === 'EN_ATTENTE' || c.proposition?.statut === 'EN_ATTENTE').length;
  const acceptees   = filtered.filter((c: any) =>
    c.statut === 'ACCEPTEE' || c.proposition?.statut === 'ACCEPTEE').length;

  const statsCards = [
    { val: filtered.length, label: 'Actives',    color: C.text },
    { val: enAttente,        label: 'En attente', color: '#D97706' },
    { val: acceptees,        label: 'Acceptées',  color: '#10B981' },
    { val: nonLusTotal,      label: 'Non lus',    color: C.primary },
  ];

  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="dark-content" backgroundColor={C.background} />

      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.headerTitle}>Discussions 💬</Text>
          <Text style={s.headerSub}>Négociations & échanges en cours</Text>
        </View>
        <TouchableOpacity style={[s.iconBtn, { backgroundColor: C.primary }]}
          onPress={() => refetch()}>
          <Text style={{ fontSize: 14, color: '#fff' }}>↺</Text>
        </TouchableOpacity>
      </View>

      {/* Recherche */}
      <View style={s.searchRow}>
        <Text style={s.searchIco}>🔍</Text>
        <TextInput style={s.searchInput}
          placeholder="Rechercher une conversation..."
          placeholderTextColor={C.textMuted}
          value={search} onChangeText={setSearch} />
      </View>

      {/* Stats */}
      <View style={s.statsRow}>
        {statsCards.map((st, i) => (
          <View key={i} style={s.statCard}>
            <Text style={[s.statVal, { color: st.color }]}>{st.val}</Text>
            <Text style={s.statLabel}>{st.label}</Text>
          </View>
        ))}
      </View>

      {/* Filtres type */}
      <View style={s.typeFilters}>
        {(['Tout', 'Troc', 'Vente', 'Don'] as FilterType[]).map(f => (
          <TouchableOpacity key={f}
            style={[s.typeFilter, typeFilter === f && s.typeFilterOn]}
            onPress={() => setTypeFilter(f)}>
            <Text style={[s.typeFilterTxt, typeFilter === f && s.typeFilterTxtOn]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Filtres statut */}
      <View style={s.statusFilters}>
        {(['Tous', 'En attente', 'Acceptées', 'Contre-offres'] as StatusFilter[]).map(f => (
          <TouchableOpacity key={f}
            style={[s.statusChip, statusFilter === f && s.statusChipOn]}
            onPress={() => setStatus(f)}>
            <Text style={[s.statusChipTxt, statusFilter === f && s.statusChipTxtOn]}>
              {f === 'Tous' ? '⊞ Tous' : f === 'En attente' ? '⏳ En attente'
                : f === 'Acceptées' ? '✓ Acceptées' : '↩ Contre-offres'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {isLoading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={C.primary} size="large" />
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={c => String(c.id)}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 80 }}
          ListEmptyComponent={
            <View style={s.empty}>
              <Text style={s.emptyIco}>💬</Text>
              <Text style={s.emptyTxt}>Aucune conversation</Text>
              <Text style={s.emptySubTxt}>Commence par contacter un vendeur !</Text>
            </View>
          }
          renderItem={({ item: conv }) => {
            const partner = conv.participants?.find((p: any) => p.id !== user?.id)
            ?? (conv.initiateur?.id !== user?.id ? conv.initiateur : conv.destinataire);
            const statut   = STATUT_CONFIG[conv.statut] ?? STATUT_CONFIG.ACTIVE;
            const hasUnread = (conv.nonLus ?? 0) > 0;
            const cfg      = conv.annonce?.type ? (TYPE_CONFIG as any)[conv.annonce.type] : null;

            return (
              <TouchableOpacity
                style={[s.convCard, hasUnread && s.convCardUnread]}
onPress={() => {
  const p = conv.participants?.find((p: any) => p.id !== user?.id)
    ?? (conv.initiateur?.id !== user?.id ? conv.initiateur : conv.destinataire);
  router.push({
    pathname: `/chat/${conv.id}` as any,
    params: {
      partnerName: p?.nom ?? 'Utilisateur',
      annonceTitle: conv.annonce?.titre ?? '',
    },
  });
}}>
                {/* Avatar */}
                <View style={s.avatarWrap}>
                  <View style={[s.avatar, { backgroundColor: C.primary + '20' }]}>
                    <Text style={s.avatarTxt}>{(partner?.nom ?? '?').charAt(0)}</Text>
                  </View>
                  {cfg && (
                    <View style={[s.typeIcon, { backgroundColor: cfg.color }]}>
                      <Text style={{ fontSize: 9, color: '#fff', fontWeight: '800' }}>{cfg.emoji}</Text>
                    </View>
                  )}
                </View>

                {/* Corps */}
                <View style={s.convBody}>
                  <View style={s.convTop}>
                    <Text style={[s.convName, hasUnread && { fontWeight: '800', color: C.text }]}>
                      {partner?.nom ?? '—'}
                    </Text>
                    <Text style={s.convTime}>
                      {conv.dernierMessage?.createdAt
                        ? new Date(conv.dernierMessage.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
                        : ''}
                    </Text>
                  </View>
                  <Text style={s.convAnnonce} numberOfLines={1}>
                    {conv.annonce?.titre ?? ''}
                  </Text>
                  <Text style={[s.convLast, hasUnread && { color: C.text, fontWeight: '500' }]}
                    numberOfLines={1}>
                    {conv.dernierMessage?.contenu ?? 'Démarrer la conversation'}
                  </Text>
                  {statut.label ? (
                    <View style={[s.statutBadge, { backgroundColor: statut.bg }]}>
                      <Text style={[s.statutTxt, { color: statut.color }]}>{statut.label}</Text>
                    </View>
                  ) : null}
                </View>

                {/* Badge non lus */}
                {(conv.nonLus ?? 0) > 0 && (
                  <View style={s.unreadBadge}>
                    <Text style={s.unreadTxt}>{conv.nonLus}</Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          }}
          ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        />
      )}

      {/* FAB */}
      <TouchableOpacity style={s.fab} onPress={() => router.push('/publier' as any)}>
        <Text style={s.fabTxt}>+</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

function makeStyles(C: any) {
  return StyleSheet.create({ 
  root:         { flex: 1, backgroundColor: C.background },
  header:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 4, paddingBottom: 12 },
  headerTitle:  { fontSize: 22, fontWeight: '800', color: C.text },
  headerSub:    { fontSize: 12, color: C.textMuted, marginTop: 1 },
  iconBtn:      { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  searchRow:    { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginBottom: 12, backgroundColor: C.surface, borderRadius: 12, borderWidth: 1, borderColor: C.border, paddingHorizontal: 12 },
  searchIco:    { fontSize: 14, marginRight: 8 },
  searchInput:  { flex: 1, paddingVertical: 11, fontSize: 14, color: C.text },
  statsRow:     { flexDirection: 'row', paddingHorizontal: 16, gap: 10, marginBottom: 12 },
  statCard:     { flex: 1, backgroundColor: C.surface, borderRadius: 12, padding: 10, alignItems: 'center', borderWidth: 1, borderColor: C.border },
  statVal:      { fontSize: 18, fontWeight: '800' },
  statLabel:    { fontSize: 10, color: C.textMuted, marginTop: 2, textAlign: 'center' },
  typeFilters:  { flexDirection: 'row', marginHorizontal: 16, borderBottomWidth: 1, borderBottomColor: C.border, marginBottom: 10 },
  typeFilter:   { flex: 1, paddingVertical: 10, alignItems: 'center' },
  typeFilterOn: { borderBottomWidth: 2, borderBottomColor: C.primary },
  typeFilterTxt:    { fontSize: 14, color: C.textMuted, fontWeight: '500' },
  typeFilterTxtOn:  { color: C.primary, fontWeight: '800' },
  statusFilters:{ flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 14 },
  statusChip:   { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, backgroundColor: C.surface, borderWidth: 1.5, borderColor: C.border },
  statusChipOn: { backgroundColor: C.primary, borderColor: C.primary },
  statusChipTxt:    { fontSize: 12, color: C.textMuted, fontWeight: '500' },
  statusChipTxtOn:  { color: '#fff', fontWeight: '700' },
  convCard:     { flexDirection: 'row', alignItems: 'flex-start', gap: 12, backgroundColor: C.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.border },
  convCardUnread: { borderColor: C.primary + '40', backgroundColor: C.primary + '08' },
  avatarWrap:   { position: 'relative' },
  avatar:       { width: 50, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: C.border },
  avatarTxt:    { fontWeight: '800', fontSize: 18, color: C.primary },
  typeIcon:     { position: 'absolute', bottom: -2, right: -2, width: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: '#fff' },
  convBody:     { flex: 1 },
  convTop:      { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 2 },
  convName:     { fontSize: 15, fontWeight: '700', color: C.text },
  convTime:     { fontSize: 12, color: C.textMuted },
  convAnnonce:  { fontSize: 12, color: C.textMuted, marginBottom: 3 },
  convLast:     { fontSize: 13, color: C.textMuted, marginBottom: 6, lineHeight: 17 },
  statutBadge:  { flexDirection: 'row', alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  statutTxt:    { fontSize: 11, fontWeight: '700' },
  unreadBadge:  { width: 22, height: 22, borderRadius: 11, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  unreadTxt:    { color: '#fff', fontSize: 11, fontWeight: '800' },
  empty:        { alignItems: 'center', marginTop: 80, paddingHorizontal: 32 },
  emptyIco:     { fontSize: 48, marginBottom: 16 },
  emptyTxt:     { fontSize: 17, fontWeight: '700', color: C.text, marginBottom: 8 },
  emptySubTxt:  { fontSize: 14, color: C.textMuted, textAlign: 'center' },
  fab:          { position: 'absolute', bottom: 76, right: 20, width: 52, height: 52, borderRadius: 26, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', shadowColor: C.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
  fabTxt:       { color: '#fff', fontSize: 28, fontWeight: '300', lineHeight: 34 },
});
}