import { useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView,
  TextInput, Switch, StatusBar, ActivityIndicator,
  FlatList, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { annonceService } from '../../services/api';
import { useAuthStore } from '../../store/authStore';
import { CATEGORIES } from '../../constants';
import { useTheme } from '../../context/ThemeContext';

const ETATS      = ['Neuf', 'Très bon', 'Bon état', 'Correct', 'Usagé', 'À réparer'];
const DISTANCES  = ['500 m', '2 km', '5 km', 'Toute la zone'];
const TRIS       = [
  { id: '',          label: 'Plus récent',      ico: '🕐' },
  { id: 'prix_asc',  label: 'Prix croissant',   ico: '↑' },
  { id: 'prix_desc', label: 'Prix décroissant',  ico: '↓' },
];

type Filtres = {
  type:       string | null;
  categories: string[];
  etats:      string[];
  prixMin:    string;
  prixMax:    string;
  urgent:     boolean;
  negociable: boolean;
  avecPhoto:  boolean;
  tri:        string;
};

const FILTRES_VIDE: Filtres = {
  type: null, categories: [], etats: [],
  prixMin: '', prixMax: '',
  urgent: false, negociable: false, avecPhoto: false,
  tri: '',
};

export default function Explorer() {
  const { theme } = useTheme();
  const C = theme.colors;
  const s = makeStyles(C);
  const { zone } = useAuthStore();
  const [filtres, setFiltres] = useState<Filtres>(FILTRES_VIDE);
  const [applied, setApplied] = useState<Filtres>(FILTRES_VIDE);
  const [vue, setVue]         = useState<'filtres' | 'resultats'>('filtres');

  const set = <K extends keyof Filtres>(k: K, v: Filtres[K]) =>
    setFiltres(prev => ({ ...prev, [k]: v }));

  const toggle = (k: 'categories' | 'etats', val: string) =>
    setFiltres(prev => ({
      ...prev,
      [k]: prev[k].includes(val)
        ? prev[k].filter(x => x !== val)
        : [...prev[k], val],
    }));

  const reset = () => setFiltres(FILTRES_VIDE);

  // Comptage total pour le bouton "Appliquer" — rafraîchi à chaque changement de filtre
  const { data: countData, isFetching: counting } = useQuery({
  queryKey: ['count', filtres, zone?.id],
  queryFn: () =>
    annonceService.getAll({
      type: (filtres.type as any) ?? undefined,
      ville: zone?.ville,
      quartier: zone?.quartier,
      categorie: filtres.categories[0] ?? undefined,
      etat: filtres.etats[0] ?? undefined,
      urgent: filtres.urgent || undefined,
      negociable: filtres.negociable || undefined,
      avecPhoto: filtres.avecPhoto || undefined,
      prixMin: filtres.prixMin ? parseFloat(filtres.prixMin) : undefined,
      prixMax: filtres.prixMax ? parseFloat(filtres.prixMax) : undefined,
      sort: filtres.tri || undefined,
      page: 0,
      size: 1,
    } as any).then(r => r.data?.totalElements ?? r.data?.length ?? 0),
  placeholderData: (prev) => prev,
});

  // Résultats réels après "Appliquer"
  const { data: resultats, isLoading: loadingRes } = useQuery({
    queryKey: ['resultats', applied, zone?.id],
    queryFn: () => annonceService.getAll({
      type:       (applied.type as any) ?? undefined,
      ville:      zone?.ville,
      quartier:   zone?.quartier,
      categorie:  applied.categories[0] ?? undefined,
      etat:       applied.etats[0] ?? undefined,
      urgent:     applied.urgent || undefined,
      negociable: applied.negociable || undefined,
      avecPhoto:  applied.avecPhoto || undefined,
      prixMin:    applied.prixMin ? parseFloat(applied.prixMin) : undefined,
      prixMax:    applied.prixMax ? parseFloat(applied.prixMax) : undefined,
      sort:       applied.tri || undefined,
    }).then(r => r.data?.content ?? r.data ?? []),
    enabled: vue === 'resultats',
  });

  const nbActifs = [
    filtres.type,
    ...filtres.categories,
    ...filtres.etats,
    filtres.urgent, filtres.negociable, filtres.avecPhoto,
    filtres.prixMin, filtres.prixMax,
  ].filter(Boolean).length;

  const appliquer = () => {
    setApplied(filtres);
    setVue('resultats');
  };

  // ── VUE RÉSULTATS ────────────────────────────────────────
  if (vue === 'resultats') {
    const annonces: any[] = Array.isArray(resultats) ? resultats : [];
    return (
      <SafeAreaView style={s.root}>
        <StatusBar barStyle="dark-content" backgroundColor={C.background} />
        <View style={s.header}>
          <TouchableOpacity onPress={() => setVue('filtres')} style={s.backBtn}>
            <Text style={s.backIco}>←</Text>
          </TouchableOpacity>
          <Text style={s.headerTitle}>
            {loadingRes ? 'Chargement…' : `${annonces.length} résultat${annonces.length !== 1 ? 's' : ''}`}
          </Text>
          <TouchableOpacity style={s.filterFab}
            onPress={() => setVue('filtres')}>
            <Text style={{ color: '#fff', fontSize: 12, fontWeight: '700' }}>✦ Filtres</Text>
            {nbActifs > 0 && (
              <View style={s.filterFabBadge}><Text style={{ color: '#fff', fontSize: 10 }}>{nbActifs}</Text></View>
            )}
          </TouchableOpacity>
        </View>

        {loadingRes ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <ActivityIndicator color={C.primary} size="large" />
          </View>
        ) : annonces.length === 0 ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 }}>
            <Text style={{ fontSize: 48, marginBottom: 16 }}>🔍</Text>
            <Text style={{ fontSize: 17, fontWeight: '700', color: C.text, marginBottom: 8 }}>Aucune annonce</Text>
            <Text style={{ fontSize: 14, color: C.textMuted, textAlign: 'center' }}>
              Essaie d'élargir tes filtres ou de changer de zone.
            </Text>
            <TouchableOpacity style={{ marginTop: 20, backgroundColor: C.primary, borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12 }}
              onPress={() => { reset(); setVue('filtres'); }}>
              <Text style={{ color: '#fff', fontWeight: '700' }}>Réinitialiser les filtres</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FlatList
            data={annonces}
            keyExtractor={a => String(a.id)}
            numColumns={2}
            columnWrapperStyle={{ gap: 10, paddingHorizontal: 16 }}
            contentContainerStyle={{ paddingVertical: 12, gap: 10 }}
            renderItem={({ item: a }) => {
              const typeColor = a.type === 'TROC' ? C.troc : a.type === 'DON' ? C.don : C.vente;
              return (
                <TouchableOpacity style={s.card}
                  onPress={() => router.push(`/annonce/${a.id}` as any)}>
                  {a.photosUrls?.[0] ? (
                    <Image source={{ uri: a.photosUrls[0] }} style={s.cardImg} />
                  ) : (
                    <View style={[s.cardImg, { backgroundColor: typeColor + '15', alignItems: 'center', justifyContent: 'center' }]}>
                      <Text style={{ fontSize: 32 }}>
                        {a.type === 'TROC' ? '⇄' : a.type === 'DON' ? '♡' : '🏷'}
                      </Text>
                    </View>
                  )}
                  <View style={[s.cardTypeBadge, { backgroundColor: typeColor }]}>
                    <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800' }}>{a.type}</Text>
                  </View>
                  {a.urgent && (
                    <View style={s.cardUrgentBadge}><Text style={{ color: '#fff', fontSize: 9, fontWeight: '800' }}>⚡ URGENT</Text></View>
                  )}
                  <View style={s.cardBody}>
                    <Text style={s.cardTitre} numberOfLines={2}>{a.titre}</Text>
                    {a.etat && <Text style={s.cardEtat}>{a.etat}</Text>}
                    {a.prix ? (
                      <Text style={[s.cardPrix, { color: typeColor }]}>{a.prix.toLocaleString()} FCFA</Text>
                    ) : null}
                    <Text style={s.cardVille} numberOfLines={1}>📍 {a.quartier ?? a.ville ?? '—'}</Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        )}
      </SafeAreaView>
    );
  }

  // ── VUE FILTRES ───────────────────────────────────────────
  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="dark-content" backgroundColor={C.background} />

      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => router.back()} style={s.backBtn}>
          <Text style={s.backIco}>←</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>
          Filtres <Text style={{ color: C.text }}>avancés</Text>
        </Text>
        {nbActifs > 0 && (
          <View style={s.activeBadge}><Text style={s.activeTxt}>{nbActifs} actifs</Text></View>
        )}
        <TouchableOpacity onPress={reset} style={{ marginLeft: 'auto' }}>
          <Text style={s.resetTxt}>Réinitialiser</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 110 }}>

        {/* Zone active */}
        <TouchableOpacity style={s.zonePill}
          onPress={() => router.push('/(auth)/zone' as any)}>
          <Text style={{ fontSize: 14 }}>📍</Text>
          <Text style={s.zonePillTxt}>
            {zone ? zone.label : 'Aucune zone sélectionnée — Tap pour choisir'}
          </Text>
          <Text style={{ color: C.primary, fontSize: 12, fontWeight: '700' }}>Changer →</Text>
        </TouchableOpacity>

        {/* Type de transaction */}
        <Text style={s.sectionTitle}>| Type de transaction</Text>
        <View style={s.typeGrid}>
          {[
            { id: null,    label: 'Tous',  emoji: '⊞', color: C.primary },
            { id: 'TROC',  label: 'Troc',  emoji: '⇄', color: C.troc   },
            { id: 'DON',   label: 'Don',   emoji: '♡', color: C.don    },
            { id: 'VENTE', label: 'Vente', emoji: '🏷', color: C.vente  },
          ].map(t => {
            const on = filtres.type === t.id;
            return (
              <TouchableOpacity key={String(t.id)}
                style={[s.typeCard, on && { borderColor: t.color, backgroundColor: t.color + '12' }]}
                onPress={() => set('type', t.id)}>
                <View style={[s.typeCardIco, { backgroundColor: t.color + '20' }]}>
                  <Text style={{ fontSize: 18 }}>{t.emoji}</Text>
                </View>
                <Text style={[s.typeCardLabel, on && { color: t.color }]}>{t.label}</Text>
                {on && (
                  <View style={[s.typeCheck, { backgroundColor: t.color + '20' }]}>
                    <Text style={[s.typeCheckTxt, { color: t.color }]}>✓</Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Urgent */}
        <View style={s.switchRow}>
          <View style={s.switchLeft}>
            <View style={[s.switchIco, { backgroundColor: '#FEE2E225' }]}>
              <Text>⚡</Text>
            </View>
            <View>
              <Text style={s.switchLabel}>Urgent seulement</Text>
              <Text style={s.switchSub}>Annonces marquées urgentes</Text>
            </View>
          </View>
          <Switch value={filtres.urgent} onValueChange={v => set('urgent', v)}
            trackColor={{ true: C.primary, false: C.border }} thumbColor="#fff" />
        </View>

        {/* Catégorie */}
        <View style={s.sectionHead}>
          <Text style={s.sectionTitle}>| Catégorie</Text>
          <Text style={s.sectionSub}>Sélection multiple</Text>
        </View>
        <View style={s.pillWrap}>
          <TouchableOpacity
            style={[s.pill, filtres.categories.length === 0 && s.pillOn]}
            onPress={() => set('categories', [])}>
            <Text style={[s.pillTxt, filtres.categories.length === 0 && s.pillTxtOn]}>⊞ Toutes</Text>
          </TouchableOpacity>
          {CATEGORIES.map(c => {
            const on = filtres.categories.includes(c.id);
            return (
              <TouchableOpacity key={c.id} style={[s.pill, on && s.pillOn]}
                onPress={() => toggle('categories', c.id)}>
                <Text style={[s.pillTxt, on && s.pillTxtOn]}>{c.emoji} {c.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Fourchette de prix */}
        <View style={s.sectionHead}>
          <Text style={s.sectionTitle}>| Fourchette de prix</Text>
          <Text style={s.sectionSub}>Pour ventes et trocs</Text>
        </View>
        <View style={s.priceRow}>
          <View style={s.priceBox}>
            <Text style={s.priceLabel}>MINIMUM</Text>
            <TextInput style={s.priceInput}
              placeholder="0" placeholderTextColor={C.textMuted}
              value={filtres.prixMin} onChangeText={v => set('prixMin', v)}
              keyboardType="numeric" />
            <Text style={s.priceSuffix}>FCFA</Text>
          </View>
          <View style={s.priceDash}><Text style={s.priceDashTxt}>—</Text></View>
          <View style={s.priceBox}>
            <Text style={s.priceLabel}>MAXIMUM</Text>
            <TextInput style={[s.priceInput, filtres.prixMax ? { color: C.primary, fontWeight: '800' } : {}]}
              placeholder="500 000" placeholderTextColor={C.textMuted}
              value={filtres.prixMax} onChangeText={v => set('prixMax', v)}
              keyboardType="numeric" />
            <Text style={[s.priceSuffix, filtres.prixMax ? { color: C.primary } : {}]}>FCFA</Text>
          </View>
        </View>

        {/* Raccourcis prix */}
        <View style={s.pillWrap}>
          {[
            { label: '0 – 25k',      min: '0',      max: '25000'  },
            { label: '25k – 100k',   min: '25000',  max: '100000' },
            { label: '100k – 300k',  min: '100000', max: '300000' },
            { label: '300k+',        min: '300000', max: ''       },
          ].map(p => {
            const on = filtres.prixMin === p.min && filtres.prixMax === p.max;
            return (
              <TouchableOpacity key={p.label} style={[s.pill, on && s.pillOn]}
                onPress={() => { set('prixMin', p.min); set('prixMax', p.max); }}>
                <Text style={[s.pillTxt, on && s.pillTxtOn]}>{p.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* État */}
        <Text style={s.sectionTitle}>| État de l'objet</Text>
        <View style={s.etatGrid}>
          {ETATS.map(e => {
            const on = filtres.etats.includes(e);
            return (
              <TouchableOpacity key={e}
                style={[s.etatCard, on && s.etatCardOn]}
                onPress={() => toggle('etats', e)}>
                {on && <Text style={s.etatCheck}>✓</Text>}
                <Text style={[s.etatTxt, on && { color: C.primary, fontWeight: '700' }]}>{e}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Trier par */}
        <Text style={s.sectionTitle}>| Trier par</Text>
        {TRIS.map(t => (
          <TouchableOpacity key={t.id} style={s.triRow} onPress={() => set('tri', t.id)}>
            <View style={[s.triIco, filtres.tri === t.id && { backgroundColor: C.primaryLight }]}>
              <Text style={{ fontSize: 14 }}>{t.ico}</Text>
            </View>
            <Text style={[s.triTxt, filtres.tri === t.id && { color: C.primary, fontWeight: '700' }]}>
              {t.label}
            </Text>
            {filtres.tri === t.id && <Text style={s.triCheck}>✓</Text>}
          </TouchableOpacity>
        ))}

        {/* Options supplémentaires */}
        <Text style={s.sectionTitle}>| Options supplémentaires</Text>
        {[
          { label: 'Avec photos uniquement', sub: 'Au moins 1 photo', ico: '📷', key: 'avecPhoto' as const, color: C.don },
          { label: 'Négociable uniquement',  sub: 'Prix négociable',  ico: '🤝', key: 'negociable' as const, color: C.primary },
        ].map(opt => (
          <View key={opt.key} style={s.switchRow}>
            <View style={s.switchLeft}>
              <View style={[s.switchIco, { backgroundColor: opt.color + '20' }]}>
                <Text>{opt.ico}</Text>
              </View>
              <View>
                <Text style={s.switchLabel}>{opt.label}</Text>
                <Text style={s.switchSub}>{opt.sub}</Text>
              </View>
            </View>
            <Switch value={filtres[opt.key] as boolean}
              onValueChange={v => set(opt.key, v)}
              trackColor={{ true: opt.color, false: C.border }} thumbColor="#fff" />
          </View>
        ))}
      </ScrollView>

      {/* Bouton appliquer */}
      <View style={s.applyBar}>
        <TouchableOpacity style={s.resetFab} onPress={reset}>
          <Text style={{ fontSize: 18 }}>↺</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.applyBtn} onPress={appliquer} disabled={counting}>
          {counting ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={s.applyTxt}>
              🔍 Appliquer · {countData ?? '—'} annonce{(countData ?? 0) !== 1 ? 's' : ''}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

function makeStyles(C: any) {
  return StyleSheet.create({ 
  root:          { flex: 1, backgroundColor: C.background },
  header:        { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 8, paddingBottom: 14, gap: 10 },
  backBtn:       { width: 36, height: 36, borderRadius: 10, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  backIco:       { color: C.text, fontSize: 18 },
  headerTitle:   { fontSize: 20, fontWeight: '800', color: C.primary },
  activeBadge:   { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, backgroundColor: C.primary },
  activeTxt:     { color: '#fff', fontSize: 11, fontWeight: '700' },
  resetTxt:      { color: C.primary, fontSize: 13, fontWeight: '600' },
  filterFab:     { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.primary, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8, marginLeft: 'auto' },
  filterFabBadge:{ width: 16, height: 16, borderRadius: 8, backgroundColor: '#EF4444', alignItems: 'center', justifyContent: 'center' },
  zonePill:      { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.surface, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.border, marginBottom: 20 },
  zonePillTxt:   { flex: 1, color: C.text, fontSize: 13, fontWeight: '600' },
  sectionHead:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  sectionTitle:  { fontSize: 15, fontWeight: '800', color: C.text, marginBottom: 12, marginTop: 4 },
  sectionSub:    { fontSize: 12, color: C.textMuted },
  typeGrid:      { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 },
  typeCard:      { width: '47%', backgroundColor: C.surface, borderRadius: 12, padding: 12, borderWidth: 1.5, borderColor: C.border, gap: 4 },
  typeCardIco:   { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  typeCardLabel: { fontSize: 14, fontWeight: '700', color: C.text },
  typeCheck:     { position: 'absolute', top: 8, right: 8, width: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  typeCheckTxt:  { fontSize: 11, fontWeight: '800' },
  switchRow:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: C.surface, borderRadius: 12, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: C.border },
  switchLeft:    { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  switchIco:     { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  switchLabel:   { fontSize: 14, fontWeight: '600', color: C.text },
  switchSub:     { fontSize: 11, color: C.textMuted, marginTop: 1 },
  pillWrap:      { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  pill:          { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: C.surface, borderWidth: 1.5, borderColor: C.border },
  pillOn:        { backgroundColor: C.primary, borderColor: C.primary },
  pillTxt:       { fontSize: 13, color: C.textMuted, fontWeight: '500' },
  pillTxtOn:     { color: '#fff', fontWeight: '700' },
  priceRow:      { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  priceBox:      { flex: 1, backgroundColor: C.surface, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.border },
  priceLabel:    { fontSize: 10, color: C.textMuted, fontWeight: '700', letterSpacing: 0.5, marginBottom: 4 },
  priceInput:    { fontSize: 16, fontWeight: '700', color: C.text },
  priceSuffix:   { fontSize: 11, color: C.textMuted, marginTop: 2 },
  priceDash:     { alignItems: 'center', paddingHorizontal: 4 },
  priceDashTxt:  { color: C.textMuted, fontSize: 18 },
  etatGrid:      { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  etatCard:      { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10, backgroundColor: C.surface, borderWidth: 1.5, borderColor: C.border, flexDirection: 'row', alignItems: 'center', gap: 6 },
  etatCardOn:    { borderColor: C.primary, backgroundColor: C.primaryLight },
  etatCheck:     { color: C.primary, fontSize: 12, fontWeight: '800' },
  etatTxt:       { fontSize: 13, color: C.textMuted, fontWeight: '500' },
  triRow:        { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.surface, borderRadius: 12, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: C.border },
  triIco:        { width: 36, height: 36, borderRadius: 10, backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
  triTxt:        { flex: 1, fontSize: 14, color: C.text },
  triCheck:      { color: C.primary, fontSize: 16, fontWeight: '800' },
  applyBar:      { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 16, backgroundColor: C.surface, borderTopWidth: 1, borderTopColor: C.border },
  resetFab:      { width: 48, height: 48, borderRadius: 24, backgroundColor: C.surfaceAlt, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  applyBtn:      { flex: 1, backgroundColor: C.primary, borderRadius: 14, paddingVertical: 14, alignItems: 'center', shadowColor: C.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 5 },
  applyTxt:      { color: '#fff', fontSize: 15, fontWeight: '800' },
  card:          { flex: 1, backgroundColor: C.surface, borderRadius: 14, borderWidth: 1, borderColor: C.border, overflow: 'hidden' },
  cardImg:       { width: '100%', height: 120 },
  cardTypeBadge: { position: 'absolute', top: 8, left: 8, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6 },
  cardUrgentBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: '#EF4444', paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6 },
  cardBody:      { padding: 10 },
  cardTitre:     { fontSize: 13, fontWeight: '700', color: C.text, marginBottom: 3 },
  cardEtat:      { fontSize: 11, color: C.textMuted, marginBottom: 3 },
  cardPrix:      { fontSize: 13, fontWeight: '800', marginBottom: 3 },
  cardVille:     { fontSize: 11, color: C.textMuted },
});
}