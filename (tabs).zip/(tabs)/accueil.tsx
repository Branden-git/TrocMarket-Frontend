import { useState, useEffect } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  TextInput, ActivityIndicator, Image, StatusBar,
  ScrollView, Modal, Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import { annonceService } from '../../services/api';
import { Annonce, AnnonceType } from '../../types';
import { TYPE_CONFIG } from '../../constants';
import { useTheme } from '../../context/ThemeContext';

import { useAuthStore } from '../../store/authStore';
import type { ZoneInfo } from '../../store/authStore';
import { useFavorisStore } from '../../store/favorisStore';
import { notificationService } from '../../services/api';

// ── Filtres taille fixe ──────────────────────────
const FILTERS: { label: string; value: AnnonceType | null; emoji: string }[] = [
  { label: 'Tous',  value: null,    emoji: '⊞'  },
  { label: 'Troc',  value: 'TROC',  emoji: '⇄'  },
  { label: 'Don',   value: 'DON',   emoji: '♡'  },
  { label: 'Vente', value: 'VENTE', emoji: '🏷' },
];



export default function Accueil() {
  const { user, zone, token } = useAuthStore();
  const { theme } = useTheme();
  const C = theme.colors;
  const s = makeStyles(C); // ← ajout
  // Dans le composant :
  // SUPPRIMER :

  
  // ── Les notifications DOIVENT être ici ──
  const { data: notifsData, refetch: refetchNotifs } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => notificationService.getAll().then(r => r.data),
    refetchInterval: 30000,
    enabled: !!token, // On ne fetch que si on est connecté
  });
  const [filter, setFilter]       = useState<AnnonceType | null>(null);
  const [search, setSearch]       = useState('');
  const [showNotifs, setNotifs]   = useState(false);
  const [notifLues, setLues]      = useState<number[]>([]);

  const { load: loadFavoris } = useFavorisStore();

  
  // Charger favoris au mount
  useEffect(() => { loadFavoris(); }, []);

  const { data, isLoading } = useQuery({
    queryKey: ['annonces', filter, search, zone?.id],
    queryFn: () =>
      annonceService.getAll({
        type: filter ?? undefined,
        search,
        ville:    zone?.ville    ?? undefined,
        quartier: zone?.quartier ?? undefined,
      }).then(r => r.data),
  });

  const annonces: Annonce[] = data?.content ?? [];
  const vedette  = annonces.filter(a => a.isPro || a.isBoosted).slice(0, 4);
  const recentes = annonces.slice(0, 10);

const notifications: {
  id: number;
  titre: string;
  corps: string;
  type: string;
  refId: number | null;
  lue: boolean;
  createdAt: string;
}[] = notifsData ?? [];

const nonLues = notifications.filter(n => !n.lue).length;

const marquerLue = async (id: number) => {
  await notificationService.marquerLue(id);
  refetchNotifs();
};

const marquerToutesLues = async () => {
  await notificationService.marquerToutesLues();
  refetchNotifs();
};
  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="dark-content" backgroundColor={C.background} />

      {/* ── Header ── */}
      <View style={s.header}>
        <View style={s.headerLeft}>
          <View style={s.logoMini}>
            <Text style={{ fontSize: 14, fontWeight: '900', color: C.primary }}>⇄</Text>
          </View>
          <Text style={s.logoTxt}>
            <Text style={{ color: C.primary }}>Troc</Text>
            <Text style={{ color: C.text }}>Market</Text>
          </Text>
        </View>
        <View style={s.headerRight}>
          {/* Zone badge */}
          <TouchableOpacity style={s.zoneBadge}
            onPress={() => router.push('/(auth)/zone' as any)}>
            <Text style={s.zoneTxt}>
              📍 {zone ? zone.label.split(' ').slice(0, 2).join(' ') : 'Ma zone'} ▾
            </Text>
          </TouchableOpacity>

          {/* Notification bell */}
          <TouchableOpacity style={s.iconBtn} onPress={() => setNotifs(true)}>
            <Text style={{ fontSize: 16 }}>🔔</Text>
            {nonLues > 0 && (
              <View style={s.notifDot}>
                {nonLues > 1 && (
                  <Text style={s.notifDotTxt}>{nonLues}</Text>
                )}
              </View>
            )}
          </TouchableOpacity>

          {/* Avatar */}
          <TouchableOpacity onPress={() => router.push('/(tabs)/profil')}>
            {user?.photoUrl
              ? <Image
                  source={{ uri: user.photoUrl }}
                  style={{ width: 36, height: 36, borderRadius: 18 }}
                />
              : <View style={s.avatarMini}>
                  <Text style={{ color: '#fff', fontWeight: '800', fontSize: 13 }}>
                    {user?.nom?.charAt(0).toUpperCase() ?? 'U'}
                  </Text>
                </View>
            }
          </TouchableOpacity>
        </View>
      </View>

      {/* ── Recherche ── */}
      <View style={s.searchRow}>
        <View style={s.searchBox}>
          <Text style={s.searchIco}>🔍</Text>
          <TextInput
            style={s.searchInput}
            placeholder="Rechercher un objet, catégorie..."
            placeholderTextColor={C.textMuted}
            value={search}
            onChangeText={setSearch}
          />
        </View>
        <TouchableOpacity style={s.carteBtn}
          onPress={() => router.push('/carte' as any)}>
          <Text style={s.carteTxt}>🗺 Carte</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.iconBtn}
          onPress={() => router.push('/(tabs)/explorer' as any)}>
          <Text style={{ fontSize: 18, color: C.text }}>≡</Text>
        </TouchableOpacity>
      </View>

{/* Filtres taille fixe */}
<View style={s.filtersRow}>
  {FILTERS.map(f => {
    const active = filter === f.value;
    return (
      <TouchableOpacity
        key={String(f.value)}
        style={[s.filterChip, active && s.filterChipOn]}
        onPress={() => setFilter(f.value as any)}>
        <Text style={[s.filterChipTxt, active && s.filterChipTxtOn]} numberOfLines={1}>
          {f.emoji} {f.label}
        </Text>
      </TouchableOpacity>
    );
  })}
</View>

      {/* ── Contenu ── */}
      {isLoading ? (
        <ActivityIndicator color={C.primary} style={{ marginTop: 60 }} size="large" />
      ) : (
        <FlatList
          data={[{ key: 'body' }]}
          keyExtractor={i => i.key}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 90 }}
          renderItem={() => (
            <View>
              {/* Compteur */}
              <View style={s.statsRow}>
                <Text style={s.statsCount}>
                  <Text style={{ color: C.primary, fontWeight: '800' }}>
                    {data?.totalElements ?? annonces.length}{' '}
                  </Text>
                  annonces près de vous
                </Text>
                <TouchableOpacity>
                  <Text style={s.sortTxt}>↕ Récent</Text>
                </TouchableOpacity>
              </View>

              {/* En vedette */}
              <View style={s.section}>
                <View style={s.sectionHead}>
                  <Text style={s.sectionTitle}>⭐ En vedette</Text>
                  <View style={s.proBadge}>
                    <Text style={s.proBadgeTxt}>PRO</Text>
                  </View>
                  <TouchableOpacity style={{ marginLeft: 'auto' }}>
                    <Text style={s.voirTout}>Voir tout</Text>
                  </TouchableOpacity>
                </View>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ paddingLeft: 16, gap: 12, paddingRight: 4 }}>
                  {(vedette.length > 0 ? vedette : annonces.slice(0, 3)).map(a => (
                    <VedetteCard key={a.id} annonce={a} />
                  ))}
                  {annonces.length === 0 && (
                    <View style={s.vedetteEmpty}>
                      <Text style={s.vedetteEmptyTxt}>Aucune annonce en vedette</Text>
                    </View>
                  )}
                </ScrollView>
              </View>

              {/* Annonces récentes */}
              <View style={s.section}>
                <View style={s.sectionHead}>
                  <Text style={s.sectionTitle}>📋 Annonces récentes</Text>
                  <TouchableOpacity style={{ marginLeft: 'auto' }}>
                    <Text style={s.voirTout}>Voir tout</Text>
                  </TouchableOpacity>
                </View>
                {recentes.length > 0 ? (
                  recentes.map(a => <ListCard key={a.id} annonce={a} />)
                ) : (
                  <View style={s.empty}>
                    <Text style={s.emptyIco}>📦</Text>
                    <Text style={s.emptyTitle}>Aucune annonce</Text>
                    <Text style={s.emptyTxt}>Sois le premier à publier !</Text>
                  </View>
                )}
              </View>
            </View>
          )}
        />
      )}

      {/* ── FAB ── */}
      <TouchableOpacity style={s.fab}
        onPress={() => router.push('/publier' as any)}>
        <Text style={s.fabTxt}>+</Text>
      </TouchableOpacity>

      {/* ── Modal Notifications ── */}
<Modal
  visible={showNotifs}
  transparent
  animationType="slide"
  onRequestClose={() => setNotifs(false)}>
  <View style={s.modalOverlay}>
    <View style={s.notifSheet}>
      <View style={s.notifHandle} />

      {/* Header */}
      <View style={s.notifHeader}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={s.notifTitle}>Notifications</Text>
          {nonLues > 0 && (
            <View style={s.notifCountBadge}>
              <Text style={s.notifCountTxt}>{nonLues}</Text>
            </View>
          )}
        </View>
        <View style={s.notifHeaderRight}>
          {nonLues > 0 && (
            <TouchableOpacity onPress={marquerToutesLues} style={s.toutLireBtn}>
              <Text style={s.toutLireTxt}>Tout lire</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={() => setNotifs(false)} style={s.notifCloseBtn}>
            <Text style={{ color: C.textMuted, fontSize: 16 }}>✕</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Liste */}
      {notifications.length === 0 ? (
        <View style={s.notifEmpty}>
          <Text style={s.notifEmptyIco}>🔔</Text>
          <Text style={s.notifEmptyTxt}>Aucune notification</Text>
          <Text style={{ color: C.textMuted, fontSize: 13, marginTop: 4 }}>
            Tu seras notifié ici pour tes échanges
          </Text>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>
          {notifications.map(notif => {
            // Emoji selon type
            const emoji =
              notif.type === 'PROPOSITION'  ? '🔄' :
              notif.type === 'MESSAGE'       ? '💬' :
              notif.type === 'TRANSACTION'   ? '✅' :
              notif.type === 'ANNONCE'       ? '📍' : '🔔';

            // Heure relative
            const diff = Date.now() - new Date(notif.createdAt).getTime();
            const mins  = Math.floor(diff / 60000);
            const heures = Math.floor(diff / 3600000);
            const jours  = Math.floor(diff / 86400000);
            const tempsRelatif =
              mins  < 1  ? "À l'instant" :
              mins  < 60 ? `Il y a ${mins} min` :
              heures < 24 ? `Il y a ${heures}h` :
              jours  < 7  ? `Il y a ${jours}j` :
              new Date(notif.createdAt).toLocaleDateString('fr-FR');

            return (
              <TouchableOpacity
                key={notif.id}
                style={[s.notifItem, !notif.lue && s.notifItemUnread]}
                onPress={() => {
                  marquerLue(notif.id);
                  setNotifs(false);
                  // Navigation vers la ressource
                  if (notif.type === 'PROPOSITION' && notif.refId) {
                    router.push(`/annonce/${notif.refId}` as any);
                  } else if (notif.type === 'MESSAGE' && notif.refId) {
                    router.push(`/chat/${notif.refId}` as any);
                  } else if (notif.type === 'TRANSACTION' && notif.refId) {
                    router.push(`/confirmation/${notif.refId}` as any);
                  }
                }}>
                <View style={[s.notifIco, !notif.lue && { backgroundColor: C.primaryLight }]}>
                  <Text style={{ fontSize: 20 }}>{emoji}</Text>
                </View>
                <View style={s.notifBody}>
                  <Text style={[s.notifText, !notif.lue && { fontWeight: '700', color: C.text }]}>
                    {notif.titre}
                  </Text>
                  <Text style={s.notifCorps} numberOfLines={2}>{notif.corps}</Text>
                  <Text style={s.notifTime}>{tempsRelatif}</Text>
                </View>
                {!notif.lue && <View style={s.notifUnreadDot} />}
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      )}
    </View>
  </View>
</Modal>
    </SafeAreaView>
  );
}

// ── VedetteCard avec favoris ─────────────────────
function VedetteCard({ annonce }: { annonce: Annonce }) {
  const { theme } = useTheme();
  const C = theme.colors;        // ← était COLORS
  const s = makeStyles(C);       // ← ajout
  const cfg   = TYPE_CONFIG[annonce.type];
  const photo = annonce.photosUrls?.[0];
  const { toggle, has } = useFavorisStore();
  const favori = has(annonce.id);

  return (
    <TouchableOpacity
      style={s.vCard}
      onPress={() => router.push(`/annonce/${annonce.id}` as any)}>
      {photo ? (
        <Image source={{ uri: photo }} style={s.vImg} />
      ) : (
        <View style={[s.vImg, s.vImgEmpty]}>
          <Text style={{ fontSize: 32 }}>📦</Text>
        </View>
      )}
      {annonce.isPro && (
        <View style={s.starBadge}>
          <Text style={s.starBadgeTxt}>★ PRO</Text>
        </View>
      )}
      <View style={[s.typePill, { backgroundColor: cfg.color }]}>
        <Text style={s.typePillTxt}>{cfg.emoji} {cfg.label.toUpperCase()}</Text>
      </View>

      {/* Bouton favoris fonctionnel */}
      <TouchableOpacity
        style={s.favBtn}
        onPress={e => { e.stopPropagation?.(); toggle(annonce.id); }}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Text style={[s.favIco, favori && s.favIcoOn]}>
          {favori ? '♥' : '♡'}
        </Text>
      </TouchableOpacity>

      <View style={s.vInfo}>
        <Text style={s.vTitle} numberOfLines={1}>{annonce.titre}</Text>
        {annonce.rechercheContre?.[0] && (
          <Text style={s.vRech} numberOfLines={1}>
            Cherche: {annonce.rechercheContre[0]}
          </Text>
        )}
        <View style={s.vMeta}>
          <View style={s.vAvRow}>
            <View style={[s.miniAv, { backgroundColor: C.primary }]}>
              <Text style={s.miniAvTxt}>{annonce.proprietaire.nom.charAt(0)}</Text>
            </View>
            <Text style={s.vNom}>{annonce.proprietaire.nom.split(' ')[0]}</Text>
          </View>
          <Text style={s.vDist}>{annonce.distance ?? '0.4 km'}</Text>
        </View>
        {annonce.prix != null && (
          <Text style={s.vPrix}>{annonce.prix.toLocaleString()} FCFA</Text>
        )}
      </View>
    </TouchableOpacity>
  );
}

// ── ListCard avec favoris ────────────────────────
function ListCard({ annonce }: { annonce: Annonce }) {
  const { theme } = useTheme();
  const C = theme.colors;
  const s = makeStyles(C);
  const cfg   = TYPE_CONFIG[annonce.type];
  const photo = annonce.photosUrls?.[0];
  const { toggle, has } = useFavorisStore();
  const favori = has(annonce.id);

  return (
    <TouchableOpacity
      style={s.lCard}
      onPress={() => router.push(`/annonce/${annonce.id}` as any)}>
      {photo ? (
        <Image source={{ uri: photo }} style={s.lImg} />
      ) : (
        <View style={[s.lImg, s.lImgEmpty]}>
          <Text style={{ fontSize: 26 }}>📦</Text>
        </View>
      )}
      <View style={s.lBody}>
        <Text style={s.lTitle} numberOfLines={1}>{annonce.titre}</Text>
        {annonce.rechercheContre?.[0] && (
          <Text style={s.lRech} numberOfLines={1}>
            Cherche: {annonce.rechercheContre[0]}
          </Text>
        )}
        <View style={s.lMeta}>
          <View style={s.lMetaLeft}>
            <View style={[s.miniAv, { backgroundColor: C.primary }]}>
              <Text style={s.miniAvTxt}>{annonce.proprietaire.nom.charAt(0)}</Text>
            </View>
            <Text style={s.lNom}>{annonce.proprietaire.nom.split(' ')[0]}</Text>
            <Text style={s.lRating}>
              ★ {annonce.proprietaire.scoreReputation?.toFixed(1) ?? '4.8'}
            </Text>
          </View>
          <Text style={s.lDist}>📍 {annonce.distance ?? '0.6 km'}</Text>
        </View>
      </View>
      <View style={s.lRight}>
        <View style={[s.typeChip, { backgroundColor: cfg.bg }]}>
          <Text style={[s.typeChipTxt, { color: cfg.color }]}>
            {cfg.label.toUpperCase()}
          </Text>
        </View>
        {annonce.prix != null && (
          <Text style={s.lPrix}>
            {annonce.prix.toLocaleString()}{'\n'}FCFA
          </Text>
        )}
        {/* Bouton favoris fonctionnel */}
        <TouchableOpacity
          onPress={e => { e.stopPropagation?.(); toggle(annonce.id); }}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Text style={[s.favIco, { fontSize: 20 }, favori && s.favIcoOn]}>
            {favori ? '♥' : '♡'}
          </Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

// ── Styles ───────────────────────────────────────
function makeStyles(C: any) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: C.background },
    // remplace chaque C.xxx par C.xxx
  // Header
  header:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 4, paddingBottom: 10 },
  headerLeft:   { flexDirection: 'row', alignItems: 'center', gap: 8 },
  logoMini:     { width: 32, height: 32, borderRadius: 9, backgroundColor: C.primaryLight, alignItems: 'center', justifyContent: 'center' },
  logoTxt:      { fontSize: 18, fontWeight: '800' },
  headerRight:  { flexDirection: 'row', alignItems: 'center', gap: 8 },
  zoneBadge:    { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border },
  zoneTxt:      { fontSize: 12, fontWeight: '600', color: C.primary },
  iconBtn:      { width: 36, height: 36, borderRadius: 10, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  notifDot:     { position: 'absolute', top: 5, right: 5, minWidth: 8, height: 8, borderRadius: 4, backgroundColor: C.danger, borderWidth: 1.5, borderColor: C.surface, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 1 },
  notifDotTxt:  { color: '#fff', fontSize: 7, fontWeight: '800' },
  avatarMini:   { width: 36, height: 36, borderRadius: 18, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' },

  // Search
  searchRow:    { flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 10 },
  searchBox:    { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: C.surface, borderRadius: 12, borderWidth: 1, borderColor: C.border, paddingHorizontal: 12 },
  searchIco:    { marginRight: 8, fontSize: 14 },
  searchInput:  { flex: 1, paddingVertical: 11, fontSize: 14, color: C.text },
  carteBtn:     { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12, backgroundColor: C.primaryLight, borderWidth: 1, borderColor: C.primary + '30' },
  carteTxt:     { color: C.primary, fontSize: 12, fontWeight: '700' },

  // Filtres — taille FIXE : width fixe + alignement centré
  filtersRow:      { flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 10 },
  filterChip:      { width: 88, height: 32, borderRadius: 18, backgroundColor: C.surface, borderWidth: 1.5, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  filterChipOn:    { backgroundColor: C.primary, borderColor: C.primary },
  filterChipTxt:   { fontSize: 13, color: C.textMuted, fontWeight: '500' },
  filterChipTxtOn: { color: '#fff', fontWeight: '700' },
  // Stats
  statsRow:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, marginBottom: 14 },
  statsCount:   { fontSize: 13, color: C.textSecondary },
  sortTxt:      { fontSize: 13, color: C.primary, fontWeight: '600' },

  // Sections
  section:      { marginBottom: 20 },
  sectionHead:  { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, marginBottom: 12, gap: 8 },
  sectionTitle: { fontSize: 16, fontWeight: '800', color: C.text },
  proBadge:     { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, backgroundColor: C.premiumLight },
  proBadgeTxt:  { color: C.premium, fontSize: 10, fontWeight: '800' },
  voirTout:     { color: C.primary, fontSize: 13, fontWeight: '600' },

  // Vedette
  vCard:        { width: 180, backgroundColor: C.surface, borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: C.border, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  vImg:         { width: '100%', height: 130 },
  vImgEmpty:    { backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
  starBadge:    { position: 'absolute', top: 8, left: 8, backgroundColor: C.primary, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 },
  starBadgeTxt: { color: '#fff', fontSize: 10, fontWeight: '800' },
  typePill:     { position: 'absolute', top: 8, right: 36, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6 },
  typePillTxt:  { color: '#fff', fontSize: 9, fontWeight: '800' },
  favBtn:       { position: 'absolute', top: 6, right: 8, width: 28, height: 28, borderRadius: 14, backgroundColor: C.surface + 'CC', alignItems: 'center', justifyContent: 'center' },
  favIco:       { fontSize: 16, color: C.textMuted },
  favIcoOn:     { color: C.danger },
  vInfo:        { padding: 10 },
  vTitle:       { fontSize: 13, fontWeight: '700', color: C.text, marginBottom: 2 },
  vRech:        { fontSize: 11, color: C.textMuted, marginBottom: 6 },
  vMeta:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  vAvRow:       { flexDirection: 'row', alignItems: 'center', gap: 4 },
  miniAv:       { width: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  miniAvTxt:    { color: '#fff', fontSize: 9, fontWeight: '800' },
  vNom:         { fontSize: 11, color: C.textMuted },
  vDist:        { fontSize: 11, color: C.textMuted },
  vPrix:        { fontSize: 13, fontWeight: '800', color: C.primary, marginTop: 4 },
  vedetteEmpty: { width: 180, alignItems: 'center', justifyContent: 'center', padding: 20 },
  vedetteEmptyTxt: { color: C.textMuted, fontSize: 12, textAlign: 'center' },

  // List card
  lCard:        { flexDirection: 'row', backgroundColor: C.surface, marginHorizontal: 16, marginBottom: 10, borderRadius: 14, borderWidth: 1, borderColor: C.border, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 1 },
  lImg:         { width: 90, height: 90 },
  lImgEmpty:    { backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
  lBody:        { flex: 1, padding: 10, justifyContent: 'center', gap: 3 },
  lTitle:       { fontSize: 14, fontWeight: '700', color: C.text },
  lRech:        { fontSize: 12, color: C.textMuted },
  lMeta:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  lMetaLeft:    { flexDirection: 'row', alignItems: 'center', gap: 4 },
  lNom:         { fontSize: 12, color: C.textMuted },
  lRating:      { fontSize: 11, color: C.warning, fontWeight: '700' },
  lDist:        { fontSize: 11, color: C.textMuted },
  lRight:       { padding: 10, alignItems: 'flex-end', justifyContent: 'space-between' },
  typeChip:     { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  typeChipTxt:  { fontSize: 10, fontWeight: '800' },
  lPrix:        { fontSize: 12, fontWeight: '800', color: C.primary, textAlign: 'right', lineHeight: 16 },

  // FAB
  fab:          { position: 'absolute', bottom: 76, right: 20, width: 52, height: 52, borderRadius: 26, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', shadowColor: C.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
  fabTxt:       { color: '#fff', fontSize: 28, fontWeight: '300', lineHeight: 34 },

  // Empty
  empty:        { alignItems: 'center', paddingTop: 40 },
  emptyIco:     { fontSize: 48, marginBottom: 12 },
  emptyTitle:   { fontSize: 17, fontWeight: '700', color: C.text },
  emptyTxt:     { fontSize: 14, color: C.textMuted, marginTop: 4 },

  // Modal notifications
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  notifSheet:   { backgroundColor: C.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '75%', paddingBottom: 32 },
  notifHandle:  { width: 40, height: 4, backgroundColor: C.border, borderRadius: 2, alignSelf: 'center', marginTop: 10, marginBottom: 4 },
  notifHeader:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.borderLight },
  notifTitle:   { fontSize: 18, fontWeight: '800', color: C.text },
  notifHeaderRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  toutLireBtn:  { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, backgroundColor: C.primaryLight },
  toutLireTxt:  { color: C.primary, fontSize: 12, fontWeight: '700' },
  notifCloseBtn: { width: 30, height: 30, borderRadius: 15, backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
  notifItem:    { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.borderLight },
  notifItemUnread: { backgroundColor: C.primaryUltra },
  notifIco:     { width: 44, height: 44, borderRadius: 12, backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
  notifBody:    { flex: 1 },
  notifText:    { fontSize: 14, color: C.textSecondary, lineHeight: 19 },
  notifTime:    { fontSize: 12, color: C.textMuted, marginTop: 2 },
  notifUnreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.primary },
  notifEmpty:   { alignItems: 'center', paddingVertical: 48 },
  notifEmptyIco: { fontSize: 40, marginBottom: 10 },
  notifEmptyTxt: { fontSize: 15, color: C.textMuted },
  notifCountBadge:  { backgroundColor: C.danger, borderRadius: 10, paddingHorizontal: 6, paddingVertical: 2 },
  notifCountTxt:    { color: '#fff', fontSize: 11, fontWeight: '800' },
  notifCorps:       { fontSize: 12, color: C.textMuted, marginTop: 2, lineHeight: 17 },
  });
}