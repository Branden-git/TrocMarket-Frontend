import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Switch, Modal, TextInput, Alert, StatusBar, ActivityIndicator, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAuthStore } from '../../store/authStore';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { userService } from '../../services/api';
import { useTheme } from '../../context/ThemeContext'; // ← ThemeContext à créer
import * as ImagePicker from 'expo-image-picker';

type ModalType = 'editProfil' | 'deconnexion' | 'supprimer' | null;
type Visibilite = 'public' | 'zone' | 'prive';

// ── Debounce helper ────────────────────────────────────────────────────────────
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

export default function Profil() {
  const { user, logout, setAuth, token } = useAuthStore();
  const queryClient = useQueryClient();

  // ── Thème ─────────────────────────────────────────────────────────────────
  const { theme, toggleTheme } = useTheme();
  const C = theme.colors; // alias court — remplace COLORS partout dans ce fichier
  const s = makeStyles(C); // styles recalculés à chaque changement de thème

  // ── Profil frais depuis le backend ────────────────────────────────────────
  const { data: profilFrais } = useQuery({
    queryKey: ['profil-me'],
    queryFn: () => userService.getMe().then(r => r.data),
    enabled: !!token,
  });
  const profil = profilFrais ?? user;

  // ── États : édition profil ────────────────────────────────────────────────
  const [modal, setModal]           = useState<ModalType>(null);
  const [editNom, setEditNom]       = useState('');
  const [editUsername, setEditUser] = useState('');
  const [editBio, setEditBio]       = useState('');
  const [editVille, setEditVille]   = useState('');
  const [editQuartier, setEditQrt]  = useState('');
  const [editTel, setEditTel]       = useState('');

  const [editPhoto, setEditPhoto] = useState<string | null>(profil?.photoUrl ?? null);

const pickImage = async () => {
  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (status !== 'granted') {
    Alert.alert('Permission refusée', "Autorisez l'accès à la galerie dans les paramètres.");
    return;
  }
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsEditing: true,
    aspect: [1, 1],
    quality: 0.5,
  });
  if (!result.canceled && result.assets[0]?.uri) {
    setEditPhoto(result.assets[0].uri);
  }
};

  useEffect(() => {
  if (profil) {
    setEditNom(profil.nom ?? '');
    setEditUser(profil.username ?? '');
    setEditBio(profil.bio ?? '');
    setEditVille(profil.ville ?? '');
    setEditQrt(profil.quartier ?? '');
    setEditTel(profil.telephone ?? '');
    setEditPhoto(profil.photoUrl ?? null); // ← ajout
  }
}, [profil]);

  // ── États : visibilité ────────────────────────────────────────────────────
  const [visibilite, setVisi]      = useState<Visibilite>((profil?.visibilite as Visibilite) ?? 'public');
  const [showLocation, setShowLoc] = useState<boolean>(profil?.showLocation ?? true);
  const [showTel, setShowTel]      = useState<boolean>(profil?.showTelephone ?? false);
  const [showAvis, setShowAvis]    = useState<boolean>(profil?.showAvis ?? true);

  useEffect(() => {
    if (profil) {
      setVisi((profil.visibilite as Visibilite) ?? 'public');
      setShowLoc(profil.showLocation ?? true);
      setShowTel(profil.showTelephone ?? false);
      setShowAvis(profil.showAvis ?? true);
    }
  }, [profil?.visibilite, profil?.showLocation, profil?.showTelephone, profil?.showAvis]);

  // ── États : notifications ─────────────────────────────────────────────────
  const [notifMessages, setNotifMessages] = useState<boolean>(profil?.notifMessages ?? true);
  const [notifTroc, setNotifTroc]         = useState<boolean>(profil?.notifTroc ?? true);
  const [notifPaiement, setNotifPaiement] = useState<boolean>(profil?.notifPaiement ?? true);
  const [notifZone, setNotifZone]         = useState<boolean>(profil?.notifZone ?? true);
  const [notifAvis, setNotifAvis]         = useState<boolean>(profil?.notifAvis ?? true);
  const [notifPromo, setNotifPromo]       = useState<boolean>(profil?.notifPromo ?? false);

  useEffect(() => {
    if (profil) {
      setNotifMessages(profil.notifMessages ?? true);
      setNotifTroc(profil.notifTroc ?? true);
      setNotifPaiement(profil.notifPaiement ?? true);
      setNotifZone(profil.notifZone ?? true);
      setNotifAvis(profil.notifAvis ?? true);
      setNotifPromo(profil.notifPromo ?? false);
    }
  }, [profilFrais]);

  const initiale = profil?.nom?.charAt(0).toUpperCase() ?? '?';

  // ── Mutation : sauvegarder le profil ──────────────────────────────────────
  const saveMut = useMutation({
    mutationFn: () => {
      const payload = {
        nom:       editNom.trim()      || undefined,  
        username:  editUsername.trim() || undefined,
        bio:       editBio.trim()      || undefined,
        ville:     editVille.trim()    || undefined,
        quartier:  editQuartier.trim() || undefined,
        telephone: editTel.trim()      || undefined,
        photoUrl:  editPhoto           ?? undefined, // ← ajout
      };
      return userService.updateProfil(payload);
    },
    onSuccess: async (res) => {
      if (token) await setAuth(res.data, token);
      queryClient.invalidateQueries({ queryKey: ['profil-me'] });
      Alert.alert('✅ Profil mis à jour', 'Modifications sauvegardées.');
      setModal(null);
    },
    onError: (err: any) => {
      Alert.alert('Erreur', err?.response?.data?.message ?? 'Impossible de sauvegarder.');
    },
  });

  // ── Mutation : visibilité (debounced) ─────────────────────────────────────
  const visibilityMut = useMutation({
    mutationFn: (data: Parameters<typeof userService.updateVisibilite>[0]) =>
      userService.updateVisibilite(data),
    onError: () => Alert.alert('Erreur', 'Impossible de sauvegarder la visibilité.'),
  });

  const debouncedVisi     = useDebounce(visibilite,   800);
  const debouncedShowLoc  = useDebounce(showLocation, 800);
  const debouncedShowTel  = useDebounce(showTel,      800);
  const debouncedShowAvis = useDebounce(showAvis,     800);

  const [visiReady, setVisiReady] = useState(false);
  useEffect(() => { if (profil) setVisiReady(true); }, [profil]);
  useEffect(() => {
    if (!visiReady) return;
    visibilityMut.mutate({
      visibilite:    debouncedVisi,
      showLocation:  debouncedShowLoc,
      showTelephone: debouncedShowTel,
      showAvis:      debouncedShowAvis,
    });
  }, [debouncedVisi, debouncedShowLoc, debouncedShowTel, debouncedShowAvis]);

  // ── Mutation : notifications (debounced) ──────────────────────────────────
  const notifMut = useMutation({
    mutationFn: (data: Parameters<typeof userService.updateNotifications>[0]) =>
      userService.updateNotifications(data),
    onError: () => Alert.alert('Erreur', 'Impossible de sauvegarder les notifications.'),
  });

  const debouncedNotifMsg   = useDebounce(notifMessages, 800);
  const debouncedNotifTroc  = useDebounce(notifTroc,     800);
  const debouncedNotifPaie  = useDebounce(notifPaiement, 800);
  const debouncedNotifZone  = useDebounce(notifZone,     800);
  const debouncedNotifAvis  = useDebounce(notifAvis,     800);
  const debouncedNotifPromo = useDebounce(notifPromo,    800);

  const [notifReady, setNotifReady] = useState(false);
  useEffect(() => { if (profil) setNotifReady(true); }, [profil]);
  useEffect(() => {
    if (!notifReady) return;
    notifMut.mutate({
      notifMessages: debouncedNotifMsg,
      notifTroc:     debouncedNotifTroc,
      notifPaiement: debouncedNotifPaie,
      notifZone:     debouncedNotifZone,
      notifAvis:     debouncedNotifAvis,
      notifPromo:    debouncedNotifPromo,
    });
  }, [debouncedNotifMsg, debouncedNotifTroc, debouncedNotifPaie,
      debouncedNotifZone, debouncedNotifAvis, debouncedNotifPromo]);

  // ── Mutation : supprimer le compte ────────────────────────────────────────
  const deleteMut = useMutation({
    mutationFn: () => userService.deleteMe(),
    onSuccess: async () => { await logout(); router.replace('/(auth)/onboarding'); },
    onError: (err: any) => {
      Alert.alert('Erreur', err?.response?.data?.message ?? 'Impossible de supprimer.');
    },
  });

  const handleLogout = async () => { await logout(); router.replace('/(auth)/onboarding'); };
  const handleSaveEdit = () => {
    if (!editNom.trim()) { Alert.alert('Erreur', 'Le nom est obligatoire'); return; }
    saveMut.mutate();
  };
  const handleDeleteAccount = () => {
    Alert.alert(
      '⚠️ Dernière confirmation',
      'Action irréversible. Toutes vos données seront supprimées définitivement.',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Supprimer définitivement', style: 'destructive', onPress: () => deleteMut.mutate() },
      ]
    );
  };

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.background }}>
      <StatusBar
        barStyle={theme.dark ? 'light-content' : 'dark-content'}
        backgroundColor={C.background}
      />

      {/* ── Header ── */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => router.back()} style={s.backBtn}>
          <Text style={s.backIco}>←</Text>
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={s.headerTitle}>Paramètres</Text>
          <Text style={s.headerSub}>Compte · Notifications · Visibilité</Text>
        </View>
        <View style={s.secureBadge}>
          <Text style={s.secureTxt}>🔒 Sécurisé</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>

        {/* ── Hero profil ── */}
        <View style={s.heroCard}>
          <View style={s.avatarWrap}>
            {profil?.photoUrl
              ? <Image
                  source={{ uri: profil.photoUrl }}
                  style={{ width: 70, height: 70, borderRadius: 35, borderWidth: 3, borderColor: C.primaryLight }}
                />
              : <View style={s.avatar}>
                  <Text style={s.avatarTxt}>{initiale}</Text>
                </View>
            }
            <TouchableOpacity style={s.editAvatarBtn} onPress={() => setModal('editProfil')}>
              <Text style={{ fontSize: 12 }}>✏</Text>
            </TouchableOpacity>
          </View>
          <View style={s.heroInfo}>
            <View style={s.heroNameRow}>
              <Text style={s.heroName}>{profil?.nom ?? '—'}</Text>
              {profil?.isPremium && (
                <View style={s.premiumBadge}><Text style={s.premiumTxt}>👑 Premium</Text></View>
              )}
            </View>
            <Text style={s.heroUsername}>@{profil?.username ?? '—'}</Text>
            <View style={s.heroStats}>
              <Text style={s.heroStat}>⭐ {profil?.scoreReputation?.toFixed(1) ?? '—'}</Text>
              <View style={s.heroDot} />
              <Text style={s.heroStat}>⇄ {profil?.nombreEchanges ?? 0} trocs</Text>
              {profil?.nombreDons != null && <>
                <View style={s.heroDot} />
                <Text style={s.heroStat}>♡ {profil.nombreDons} dons</Text>
              </>}
            </View>
            <Text style={s.heroVille}>
              📍 {[profil?.quartier, profil?.ville].filter(Boolean).join(', ') || '—'}
            </Text>
          </View>
        </View>

        {/* ── Premium actif ── */}
        {profil?.isPremium && (
          <View style={s.premiumCard}>
            <View style={s.premiumLeft}>
              <View style={s.premiumIco}><Text style={{ fontSize: 18 }}>👑</Text></View>
              <View>
                <Text style={s.premiumTitle}>Troc Premium</Text>
                <Text style={s.premiumSub}>Actif · Expire le {profil?.premiumExpiry ?? '—'}</Text>
              </View>
            </View>
            <View style={s.premiumActif}><Text style={s.premiumActifTxt}>Actif</Text></View>
          </View>
        )}

        {/* ── Navigation rapide ── */}
        <View style={s.quickNav}>
          {[
            // nombreAnnonces vient du backend (calculé côté serveur, pas sur l'entité User)
            { emoji: '📋', label: 'Mes Objets',    route: '/mes-objets',   stat: `${profil?.nombreAnnonces ?? 0}`,                    statLabel: 'annonces', statColor: C.primary  },
            { emoji: '💰', label: 'Portefeuille',  route: '/portefeuille', stat: '—',                                                 statLabel: 'FCFA',     statColor: C.don      },
            { emoji: '⭐', label: 'Ma réputation', route: null,            stat: `${profil?.scoreReputation?.toFixed(1) ?? '—'}/5`,   statLabel: 'note',     statColor: C.warning  },
          ].map((item, i) => (
            <TouchableOpacity key={i} style={s.quickNavCard}
              onPress={() => item.route && router.push(item.route as any)}>
              <Text style={{ fontSize: 22 }}>{item.emoji}</Text>
              <Text style={s.quickNavLabel}>{item.label}</Text>
              <Text style={[s.quickNavStat, { color: item.statColor }]}>{item.stat}</Text>
              <Text style={s.quickNavStatLabel}>{item.statLabel}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* ── GESTION DU COMPTE ── */}
        <Text style={s.groupTitle}>GESTION DU COMPTE</Text>
        <View style={s.menuGroup}>
          <MenuItem C={C} emoji="👤" title="Modifier le profil" sub="Nom, photo, bio, localisation"
            onPress={() => setModal('editProfil')} />
          <MenuItem C={C} emoji="🔒" title="Sécurité & Mot de passe" sub="Changer le mot de passe, 2FA"
            onPress={() => Alert.alert('Sécurité', 'Fonctionnalité bientôt disponible')} />
          <MenuItem C={C} emoji="📞" title="Numéro de téléphone"
            sub={profil?.telephone ? `${profil.telephone} · Renseigné` : 'Non renseigné'}
            badge={profil?.telephone ? 'Vérifié' : undefined} badgeColor={C.don}
            onPress={() => setModal('editProfil')} />
          <MenuItem C={C} emoji="✉" title="Adresse e-mail" sub={profil?.email ?? '—'} last
            onPress={() => Alert.alert('Email', 'Modification disponible bientôt')} />
        </View>

        {/* ── VISIBILITÉ DU PROFIL ── */}
        <Text style={s.groupTitle}>VISIBILITÉ DU PROFIL</Text>
        <View style={s.menuGroup}>
          {visibilityMut.isPending && (
            <View style={s.savingRow}>
              <ActivityIndicator size="small" color={C.primary} />
              <Text style={s.savingTxt}>Sauvegarde…</Text>
            </View>
          )}
          <View style={s.visiRow}>
            {([
              { id: 'public', label: 'Public',  sub: 'Tout le monde',    emoji: '🌐' },
              { id: 'zone',   label: 'Ma zone', sub: 'Région seulement', emoji: '📍' },
              { id: 'prive',  label: 'Privé',   sub: 'Contacts seuls',   emoji: '🔒' },
            ] as { id: Visibilite; label: string; sub: string; emoji: string }[]).map(v => (
              <TouchableOpacity key={v.id}
                style={[s.visiCard, visibilite === v.id && s.visiCardOn]}
                onPress={() => setVisi(v.id)}>
                {visibilite === v.id && (
                  <View style={s.visiCheck}><Text style={{ color: '#fff', fontSize: 10 }}>✓</Text></View>
                )}
                <Text style={{ fontSize: 20, marginBottom: 4 }}>{v.emoji}</Text>
                <Text style={[s.visiLabel, visibilite === v.id && { color: C.primary }]}>{v.label}</Text>
                <Text style={s.visiSub}>{v.sub}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {[
            { label: 'Afficher ma localisation', sub: 'Ville visible sur le profil',   val: showLocation, set: setShowLoc  },
            { label: 'Numéro visible',            sub: 'Affiché aux acheteurs',         val: showTel,      set: setShowTel  },
            { label: 'Afficher les avis',         sub: 'Notes et commentaires publics', val: showAvis,     set: setShowAvis },
          ].map((sw, i) => (
            <View key={i} style={[s.switchRow, i === 2 && s.switchRowLast]}>
              <View style={{ flex: 1 }}>
                <Text style={s.switchLabel}>{sw.label}</Text>
                <Text style={s.switchSub}>{sw.sub}</Text>
              </View>
              <Switch value={sw.val} onValueChange={sw.set}
                trackColor={{ true: C.primary, false: C.border }} thumbColor="#fff" />
            </View>
          ))}
        </View>

        {/* ── NOTIFICATIONS ── */}
        <Text style={s.groupTitle}>NOTIFICATIONS</Text>
        <View style={s.menuGroup}>
          {notifMut.isPending && (
            <View style={s.savingRow}>
              <ActivityIndicator size="small" color={C.primary} />
              <Text style={s.savingTxt}>Sauvegarde…</Text>
            </View>
          )}
          {[
            { emoji: '💬', label: 'Messages & Négociations',  sub: "Nouvelles offres de troc, chats",      val: notifMessages, set: setNotifMessages },
            { emoji: '⇄',  label: 'Propositions de troc',    sub: "Quand quelqu'un propose un échange",   val: notifTroc,     set: setNotifTroc     },
            { emoji: '💰', label: 'Paiements & Transactions', sub: 'Confirmations, reçus, remboursements', val: notifPaiement, set: setNotifPaiement },
            { emoji: '📍', label: 'Alertes de zone',          sub: 'Nouvelles annonces près de chez moi',  val: notifZone,     set: setNotifZone     },
            { emoji: '⭐', label: 'Avis & Notations',         sub: "Quand un acheteur vous note",          val: notifAvis,     set: setNotifAvis     },
            { emoji: '🎁', label: 'Promotions & Offres',      sub: 'Bons plans, réductions',               val: notifPromo,    set: setNotifPromo    },
          ].map((notif, i, arr) => (
            <View key={i} style={[s.switchRow, i === arr.length - 1 && s.switchRowLast]}>
              <View style={[s.notifIco, { backgroundColor: C.surfaceAlt }]}>
                <Text style={{ fontSize: 16 }}>{notif.emoji}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.switchLabel}>{notif.label}</Text>
                <Text style={s.switchSub}>{notif.sub}</Text>
              </View>
              <Switch value={notif.val} onValueChange={notif.set}
                trackColor={{ true: C.primary, false: C.border }} thumbColor="#fff" />
            </View>
          ))}
        </View>

        {/* ── PRÉFÉRENCES ── */}
        <Text style={s.groupTitle}>PRÉFÉRENCES</Text>
        <View style={s.menuGroup}>
          {/* Langue : statique, pas de modal */}
          <View style={s.menuRow}>
            <View style={s.menuIco}><Text style={{ fontSize: 18 }}>🌐</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.menuLabel}>Langue</Text>
              <Text style={s.menuSub}>Français · Cameroun</Text>
            </View>
            <View style={[s.menuBadge, { backgroundColor: C.primaryLight }]}>
              <Text style={[s.menuBadgeTxt, { color: C.primary }]}>Par défaut</Text>
            </View>
          </View>

          <MenuItem C={C} emoji="📍" title="Zone par défaut" sub="Yaoundé · Centre"
            onPress={() => router.push('/(auth)/zone' as any)} />

          {/* Mode sombre — toggle branché sur ThemeContext */}
          <View style={[s.switchRow, s.switchRowLast]}>
            <View style={[s.notifIco, { backgroundColor: C.surfaceAlt }]}>
              <Text style={{ fontSize: 16 }}>🌙</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.switchLabel}>Mode sombre</Text>
              <Text style={s.switchSub}>
                {theme.dark ? 'Activé · Thème sombre' : 'Désactivé · Thème clair'}
              </Text>
            </View>
            <Switch
              value={theme.dark}
              onValueChange={toggleTheme}
              trackColor={{ true: C.primary, false: C.border }}
              thumbColor="#fff"
            />
          </View>
        </View>

        {/* ── ZONE DE DANGER ── */}
        <Text style={s.groupTitle}>ZONE DE DANGER</Text>
        <View style={s.menuGroup}>
          <TouchableOpacity style={s.dangerRow} onPress={() => setModal('deconnexion')}>
            <View style={[s.dangerIco, { backgroundColor: C.warningLight }]}>
              <Text style={{ fontSize: 18 }}>🚪</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.dangerLabel, { color: C.warning }]}>Se déconnecter</Text>
              <Text style={s.dangerSub}>Déconnexion de ce compte</Text>
            </View>
            <Text style={{ color: C.warning, fontSize: 18 }}>›</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.dangerRow, s.dangerRowLast]} onPress={() => setModal('supprimer')}>
            <View style={[s.dangerIco, { backgroundColor: C.dangerLight }]}>
              <Text style={{ fontSize: 18 }}>🗑</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.dangerLabel, { color: C.danger }]}>Supprimer le compte</Text>
              <Text style={s.dangerSub}>Action irréversible, données supprimées</Text>
            </View>
            <Text style={{ color: C.danger, fontSize: 18 }}>›</Text>
          </TouchableOpacity>
        </View>

        <Text style={s.version}>Troc Cameroun v2.4.1 · Build 2025.05</Text>
      </ScrollView>

      {/* ══ MODAL ÉDITION PROFIL ══ */}
      <Modal visible={modal === 'editProfil'} transparent animationType="slide"
        onRequestClose={() => setModal(null)}>
        <View style={s.modalOverlay}>
          <ScrollView keyboardShouldPersistTaps="handled">
            <View style={[s.modalSheet, { paddingBottom: 40 }]}>
              <View style={s.modalHandle} />
              <View style={s.modalHeaderRow}>
                <Text style={s.modalTitle}>Modifier le profil</Text>
                <TouchableOpacity onPress={() => setModal(null)} style={s.modalCloseBtn}>
                  <Text style={{ color: C.textMuted }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity onPress={pickImage} style={{ alignItems: 'center', marginBottom: 20 }}>
  {editPhoto
    ? <Image
        source={{ uri: editPhoto }}
        style={{ width: 80, height: 80, borderRadius: 40, marginBottom: 4 }}
      />
    : <View style={s.editAvatar}>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 28 }}>{initiale}</Text>
      </View>
  }
  <View style={s.editAvatarLabel}>
    <Text style={{ fontSize: 12 }}>📷</Text>
  </View>
  <Text style={s.editAvatarHint}>Appuyer pour changer la photo</Text>
</TouchableOpacity>
              {[
                { label: 'NOM COMPLET *',    val: editNom,      set: setEditNom,   placeholder: 'Votre nom complet' },
                { label: "NOM D'UTILISATEUR",val: editUsername, set: setEditUser,  placeholder: '@username' },
                { label: 'BIO',              val: editBio,      set: setEditBio,   placeholder: 'Parlez de vous…', multi: true },
                { label: 'VILLE',            val: editVille,    set: setEditVille, placeholder: 'Ex : Yaoundé' },
                { label: 'QUARTIER',         val: editQuartier, set: setEditQrt,   placeholder: 'Ex : Bastos' },
                { label: 'TÉLÉPHONE',        val: editTel,      set: setEditTel,   placeholder: '+237 6XX XXX XXX' },
              ].map((f, i) => (
                <View key={i} style={{ marginBottom: 14 }}>
                  <Text style={s.editFieldLabel}>{f.label}</Text>
                  <TextInput
                    style={[s.editInput, (f as any).multi && { height: 80, textAlignVertical: 'top' }]}
                    placeholder={f.placeholder} placeholderTextColor={C.textMuted}
                    value={f.val} onChangeText={f.set}
                    multiline={(f as any).multi}
                    keyboardType={f.label === 'TÉLÉPHONE' ? 'phone-pad' : 'default'}
                  />
                </View>
              ))}
              <TouchableOpacity
                style={[s.modalCta, saveMut.isPending && { opacity: 0.6 }]}
                onPress={handleSaveEdit} disabled={saveMut.isPending}>
                {saveMut.isPending
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={s.modalCtaTxt}>✓ Sauvegarder les modifications</Text>
                }
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>

      {/* ══ MODAL DÉCONNEXION ══ */}
      <Modal visible={modal === 'deconnexion'} transparent animationType="slide"
        onRequestClose={() => setModal(null)}>
        <View style={s.modalOverlay}>
          <View style={s.modalSheet}>
            <View style={s.modalHandle} />
            <View style={{ alignItems: 'center', marginBottom: 20 }}>
              <View style={[s.modalBigIco, { backgroundColor: C.warningLight }]}>
                <Text style={{ fontSize: 28 }}>🚪</Text>
              </View>
              <Text style={s.modalTitle}>Se déconnecter ?</Text>
              <Text style={s.modalDesc}>Vous serez déconnecté de votre Troc. Vos données resteront sauvegardées.</Text>
            </View>
            <View style={s.modalBtnRow}>
              <TouchableOpacity style={s.modalBtnCancel} onPress={() => setModal(null)}>
                <Text style={s.modalBtnCancelTxt}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.modalBtnAction, { backgroundColor: C.warning }]}
                onPress={handleLogout}>
                <Text style={s.modalBtnActionTxt}>Se déconnecter</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ══ MODAL SUPPRIMER COMPTE ══ */}
      <Modal visible={modal === 'supprimer'} transparent animationType="slide"
        onRequestClose={() => setModal(null)}>
        <View style={s.modalOverlay}>
          <View style={s.modalSheet}>
            <View style={s.modalHandle} />
            <View style={{ alignItems: 'center', marginBottom: 20 }}>
              <View style={[s.modalBigIco, { backgroundColor: C.dangerLight }]}>
                <Text style={{ fontSize: 28 }}>⚠</Text>
              </View>
              <Text style={s.modalTitle}>Supprimer le compte ?</Text>
              <Text style={s.modalDesc}>
                Cette action est <Text style={{ fontWeight: '800', color: C.danger }}>irréversible</Text>.
                Toutes vos annonces, transactions et données seront définitivement supprimées.
              </Text>
            </View>
            <View style={[s.modalWarnBox, { backgroundColor: C.dangerLight, borderColor: C.danger + '40' }]}>
              <Text style={{ fontSize: 14 }}>⚠</Text>
              <Text style={[s.modalWarnTxt, { color: C.danger }]}>
                Vous perdrez : {profil?.nombreAnnonces ?? 0} annonces,
                votre historique de trocs et votre abonnement Premium restant.
              </Text>
            </View>
            <View style={s.modalBtnRow}>
              <TouchableOpacity style={s.modalBtnCancel} onPress={() => setModal(null)}>
                <Text style={s.modalBtnCancelTxt}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.modalBtnAction, { backgroundColor: C.danger }, deleteMut.isPending && { opacity: 0.6 }]}
                onPress={handleDeleteAccount} disabled={deleteMut.isPending}>
                {deleteMut.isPending
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={s.modalBtnActionTxt}>Supprimer</Text>
                }
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* FAB */}
      <TouchableOpacity style={s.fab} onPress={() => router.push('/publier' as any)}>
        <Text style={s.fabTxt}>+</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

// ── MenuItem (reçoit C pour les couleurs dynamiques) ──────────────────────────
function MenuItem({ C, emoji, title, sub, badge, badgeColor, onPress, last }: {
  C: ReturnType<typeof makeStyles>['__colors__']; // juste pour typer — voir note ci-dessous
  emoji: string; title: string; sub: string;
  badge?: string; badgeColor?: string;
  onPress: () => void; last?: boolean;
}) {
  const s = makeStyles(C);
  return (
    <TouchableOpacity style={[s.menuRow, last && s.menuRowLast]} onPress={onPress}>
      <View style={s.menuIco}><Text style={{ fontSize: 18 }}>{emoji}</Text></View>
      <View style={{ flex: 1 }}>
        <Text style={s.menuLabel}>{title}</Text>
        <Text style={s.menuSub}>{sub}</Text>
      </View>
      {badge && (
        <View style={[s.menuBadge, { backgroundColor: (badgeColor ?? C.primary) + '20' }]}>
          <Text style={[s.menuBadgeTxt, { color: badgeColor ?? C.primary }]}>{badge}</Text>
        </View>
      )}
      <Text style={s.menuArrow}>›</Text>
    </TouchableOpacity>
  );
}

// ── Styles dynamiques (recalculés à chaque changement de thème) ───────────────
function makeStyles(C: ReturnType<typeof import('../../context/ThemeContext').useTheme>['theme']['colors']) {
  return StyleSheet.create({
    header:            { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 4, paddingBottom: 12, gap: 8 },
    backBtn:           { width: 36, height: 36, borderRadius: 10, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
    backIco:           { color: C.text, fontSize: 18 },
    headerTitle:       { fontSize: 20, fontWeight: '800', color: C.text },
    headerSub:         { fontSize: 12, color: C.textMuted },
    secureBadge:       { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, backgroundColor: C.donLight, borderWidth: 1, borderColor: C.don + '40' },
    secureTxt:         { color: C.don, fontSize: 11, fontWeight: '600' },
    heroCard:          { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: C.surface, marginHorizontal: 16, marginBottom: 12, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border },
    avatarWrap:        { position: 'relative' },
    avatar:            { width: 70, height: 70, borderRadius: 35, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: C.primaryLight },
    avatarTxt:         { color: '#fff', fontSize: 28, fontWeight: '800' },
    editAvatarBtn:     { position: 'absolute', bottom: -2, right: -2, width: 24, height: 24, borderRadius: 12, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
    heroInfo:          { flex: 1 },
    heroNameRow:       { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 2 },
    heroName:          { fontSize: 18, fontWeight: '800', color: C.text },
    premiumBadge:      { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, backgroundColor: C.premiumLight },
    premiumTxt:        { color: C.premium, fontSize: 11, fontWeight: '700' },
    heroUsername:      { fontSize: 13, color: C.textMuted, marginBottom: 4 },
    heroStats:         { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
    heroStat:          { fontSize: 12, color: C.textSecondary, fontWeight: '600' },
    heroDot:           { width: 3, height: 3, borderRadius: 2, backgroundColor: C.textMuted },
    heroVille:         { fontSize: 12, color: C.textMuted },
    premiumCard:       { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginBottom: 12, backgroundColor: C.premiumLight, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.premium + '30' },
    premiumLeft:       { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
    premiumIco:        { width: 40, height: 40, borderRadius: 10, backgroundColor: C.premium + '20', alignItems: 'center', justifyContent: 'center' },
    premiumTitle:      { fontSize: 14, fontWeight: '800', color: C.premium },
    premiumSub:        { fontSize: 12, color: C.premium + 'A0' },
    premiumActif:      { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, backgroundColor: C.don },
    premiumActifTxt:   { color: '#fff', fontSize: 12, fontWeight: '700' },
    quickNav:          { flexDirection: 'row', paddingHorizontal: 16, gap: 10, marginBottom: 20 },
    quickNavCard:      { flex: 1, backgroundColor: C.surface, borderRadius: 14, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: C.border },
    quickNavLabel:     { fontSize: 11, color: C.textMuted, marginTop: 4, marginBottom: 4, textAlign: 'center' },
    quickNavStat:      { fontSize: 16, fontWeight: '800' },
    quickNavStatLabel: { fontSize: 10, color: C.textMuted },
    groupTitle:        { fontSize: 11, fontWeight: '700', color: C.textMuted, letterSpacing: 1, paddingHorizontal: 16, marginBottom: 8, marginTop: 4 },
    menuGroup:         { marginHorizontal: 16, marginBottom: 16, backgroundColor: C.surface, borderRadius: 16, borderWidth: 1, borderColor: C.border, overflow: 'hidden' },
    menuRow:           { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.borderLight, gap: 12 },
    menuRowLast:       { borderBottomWidth: 0 },
    menuIco:           { width: 38, height: 38, borderRadius: 10, backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
    menuLabel:         { fontSize: 14, fontWeight: '600', color: C.text },
    menuSub:           { fontSize: 12, color: C.textMuted, marginTop: 1 },
    menuBadge:         { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
    menuBadgeTxt:      { fontSize: 11, fontWeight: '700' },
    menuArrow:         { fontSize: 20, color: C.textMuted },
    savingRow:         { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, paddingVertical: 8, backgroundColor: C.primaryUltra, borderBottomWidth: 1, borderBottomColor: C.borderLight },
    savingTxt:         { fontSize: 12, color: C.primary, fontWeight: '600' },
    visiRow:           { flexDirection: 'row', gap: 8, padding: 12, borderBottomWidth: 1, borderBottomColor: C.borderLight },
    visiCard:          { flex: 1, backgroundColor: C.surfaceAlt, borderRadius: 12, padding: 10, alignItems: 'center', borderWidth: 1.5, borderColor: C.border, position: 'relative' },
    visiCardOn:        { borderColor: C.primary, backgroundColor: C.primaryLight },
    visiCheck:         { position: 'absolute', top: 4, right: 4, width: 18, height: 18, borderRadius: 9, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' },
    visiLabel:         { fontSize: 12, fontWeight: '700', color: C.text, textAlign: 'center' },
    visiSub:           { fontSize: 10, color: C.textMuted, textAlign: 'center', marginTop: 2 },
    switchRow:         { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.borderLight, gap: 12 },
    switchRowLast:     { borderBottomWidth: 0 },
    switchLabel:       { fontSize: 14, fontWeight: '600', color: C.text },
    switchSub:         { fontSize: 12, color: C.textMuted, marginTop: 1 },
    notifIco:          { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
    dangerRow:         { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.borderLight, gap: 12 },
    dangerRowLast:     { borderBottomWidth: 0 },
    dangerIco:         { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
    dangerLabel:       { fontSize: 14, fontWeight: '700' },
    dangerSub:         { fontSize: 12, color: C.textMuted, marginTop: 1 },
    version:           { textAlign: 'center', color: C.textMuted, fontSize: 11, paddingVertical: 20 },
    fab:               { position: 'absolute', bottom: 28, right: 20, width: 52, height: 52, borderRadius: 26, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', shadowColor: C.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
    fabTxt:            { color: '#fff', fontSize: 28, fontWeight: '300', lineHeight: 34 },
    modalOverlay:      { flex: 1, backgroundColor: C.overlay, justifyContent: 'flex-end' },
    modalSheet:        { backgroundColor: C.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingTop: 12, maxHeight: '90%' },
    modalHandle:       { width: 40, height: 4, backgroundColor: C.border, borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
    modalHeaderRow:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
    modalTitle:        { fontSize: 20, fontWeight: '800', color: C.text },
    modalCloseBtn:     { width: 32, height: 32, borderRadius: 16, backgroundColor: C.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
    modalDesc:         { fontSize: 14, color: C.textMuted, textAlign: 'center', lineHeight: 20, marginTop: 6 },
    modalBigIco:       { width: 72, height: 72, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
    modalWarnBox:      { flexDirection: 'row', gap: 10, borderRadius: 12, padding: 12, marginBottom: 20, borderWidth: 1 },
    modalWarnTxt:      { flex: 1, fontSize: 12, lineHeight: 17 },
    modalBtnRow:       { flexDirection: 'row', gap: 12 },
    modalBtnCancel:    { flex: 1, paddingVertical: 14, borderRadius: 12, borderWidth: 1.5, borderColor: C.border, alignItems: 'center' },
    modalBtnCancelTxt: { fontSize: 15, fontWeight: '600', color: C.textSecondary },
    modalBtnAction:    { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
    modalBtnActionTxt: { fontSize: 15, fontWeight: '800', color: '#fff' },
    modalCta:          { marginTop: 10, paddingVertical: 14, borderRadius: 14, backgroundColor: C.primary, alignItems: 'center' },
    modalCtaTxt:       { fontSize: 15, fontWeight: '800', color: '#fff' },
    editAvatar:        { width: 80, height: 80, borderRadius: 40, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
    editAvatarLabel:   { width: 32, height: 32, borderRadius: 16, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', marginTop: -16, marginBottom: 6, borderWidth: 2, borderColor: '#fff' },
    editAvatarHint:    { fontSize: 12, color: C.textMuted },
    editFieldLabel:    { fontSize: 11, fontWeight: '700', color: C.textMuted, letterSpacing: 1, marginBottom: 7 },
    editInput:         { backgroundColor: C.surfaceAlt, borderWidth: 1, borderColor: C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: C.text },
    // clé fantôme utilisée uniquement pour le typage de MenuItem
    __colors__:        {} as any,
  });
}