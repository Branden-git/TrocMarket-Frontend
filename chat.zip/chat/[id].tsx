import { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList,
  TextInput, KeyboardAvoidingView, Platform, Alert,
  StatusBar, ActivityIndicator, RefreshControl,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { chatService, propositionService } from '../../services/api';
import { useTheme } from '../../context/ThemeContext';

import { useAuthStore } from '../../store/authStore';

type MessageLocal = {
  id: number;
  auteurId: number;
  contenu: string;
  type: 'TEXT' | 'PROPOSITION' | 'SYSTEME';
  createdAt: string;
  _tempId?: number;      // ← pour tracker les messages optimistes
  _pending?: boolean;    // ← true = pas encore confirmé par le serveur
  proposition?: {
    id: number;
    statut: 'EN_ATTENTE' | 'ACCEPTEE' | 'REFUSEE' | 'CONTRE_OFFRE';
    offre: { titre: string; valeur: number };
    recu: { titre: string; valeur: number };
    valeurTotale: number;
    sentByMe: boolean;
  };
};

const QUICK_REPLIES = ["D'accord 👍", 'Je suis intéressé', 'Lieu de RDV ?', 'Quel état ?'];

// ── Normalise un message brut venant de l'API ────────────
function normalizeMessage(m: any, myId?: number): MessageLocal {
  const auteurId = m.auteurId ?? m.auteur?.id ?? m.expediteurId ?? m.senderId ?? 0;
  return {
    id: m.id,
    auteurId,
    contenu: m.contenu ?? m.texte ?? m.content ?? '',
    type: m.type ?? 'TEXT',
    createdAt: m.createdAt
      ? new Date(m.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
      : '',
    proposition: m.proposition
      ? {
          id: m.proposition.id,
          statut: m.proposition.statut,
          sentByMe: (m.proposition.expediteurId ?? m.proposition.senderId) === myId,
          offre: m.proposition.objetOffert ?? { titre: '—', valeur: 0 },
          recu:  m.proposition.objetDemande  ?? { titre: '—', valeur: 0 },
          valeurTotale: m.proposition.valeurTotale ?? 0,
        }
      : undefined,
  };
}

export default function Chat() {
  const { theme } = useTheme();
  const C = theme.colors;
  const s = makeStyles(C);
  const { id, partnerName: pn, annonceTitle } = useLocalSearchParams<{
    id: string; partnerName?: string; annonceTitle?: string;
  }>();
  const { user } = useAuthStore();
  const flatListRef = useRef<FlatList>(null);
  const pollRef     = useRef<ReturnType<typeof setInterval> | null>(null);
  // Garde les tempIds en attente pour ne pas les écraser pendant le polling
  const pendingTempIds = useRef<Set<number>>(new Set());

  const [messages, setMessages]     = useState<MessageLocal[]>([]);
  const [texte, setTexte]           = useState('');
  const [sending, setSending]       = useState(false);
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [contreOffreId, setContreOffreId]   = useState<number | null>(null);
  const [contreOffreTxt, setContreOffreTxt] = useState('');

  const convId      = Number(id);
  const partnerName = pn ?? 'Utilisateur';

  // ── Chargement & merge intelligent ──────────────────────
  const fetchMessages = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await chatService.getMessages(convId);

      // Supporte { data: [] }, { messages: [] } ou tableau direct
      const raw: any[] = Array.isArray(res.data)
        ? res.data
        : res.data?.messages ?? res.data?.data ?? [];

      const fetched = raw.map(m => normalizeMessage(m, user?.id));

      setMessages(prev => {
        // Récupère les messages optimistes encore en attente
        const pending = prev.filter(m => m._pending && pendingTempIds.current.has(m._tempId ?? -1));

        // IDs déjà reçus du serveur
        const serverIds = new Set(fetched.map(m => m.id));

        // Filtre les pending qui n'ont pas encore d'équivalent côté serveur
        const stillPending = pending.filter(m => !serverIds.has(m.id));

        // Évite les re-renders inutiles si rien n'a changé
        const merged = [...fetched, ...stillPending];
        const prevIds = prev.filter(m => !m._pending).map(m => m.id).join(',');
        const nextIds = fetched.map(m => m.id).join(',');
        if (prevIds === nextIds && stillPending.length === 0) return prev;

        return merged;
      });

      if (!silent) {
        setTimeout(() => flatListRef.current?.scrollToEnd({ animated: false }), 100);
      }
    } catch {
      if (!silent) Alert.alert('Erreur', 'Impossible de charger les messages');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [convId, user?.id]);

  useEffect(() => {
    fetchMessages();
    pollRef.current = setInterval(() => fetchMessages(true), 5000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [fetchMessages]);

  // ── Envoyer un message ───────────────────────────────────
  const sendMessage = async (contenu?: string) => {
    const txt = (contenu ?? texte).trim();
    if (!txt || !user?.id || sending) return;

    const tempId = Date.now();
    pendingTempIds.current.add(tempId);
    setSending(true);

    const optimistic: MessageLocal = {
      id: tempId,           // ID temporaire (grand entier, ne collisionne pas)
      _tempId: tempId,
      _pending: true,
      auteurId: user.id,
      contenu: txt,
      type: 'TEXT',
      createdAt: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, optimistic]);
    setTexte('');
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 80);

    try {
      const response = await chatService.sendMessage(convId, txt);
      const newMsg   = response?.data;

      setMessages(prev =>
        prev.map(m =>
          m._tempId === tempId
            ? {
                ...normalizeMessage(newMsg ?? {}, user.id),
                // Si le backend ne renvoie pas l'id, on garde tempId pour éviter le doublon
                id: newMsg?.id ?? tempId,
                _pending: false,
                _tempId: tempId,
              }
            : m
        )
      );
    } catch {
      // Retire le message optimiste en cas d'échec
      setMessages(prev => prev.filter(m => m._tempId !== tempId));
      Alert.alert('Erreur', "Impossible d'envoyer le message. Veuillez réessayer.");
    } finally {
      pendingTempIds.current.delete(tempId);
      setSending(false);
    }
  };

  // ── Accepter une proposition ─────────────────────────────
  const handleAccepter = (propId: number) => {
    Alert.alert('Accepter la proposition', "Confirmes-tu l'échange ?", [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Confirmer',
        onPress: async () => {
          try {
            await propositionService.updateStatut(propId, 'ACCEPTEE');
            await fetchMessages(true);
            Alert.alert('✅ Acceptée', 'La proposition a été acceptée !');
          } catch {
            Alert.alert('Erreur', "Impossible d'accepter la proposition");
          }
        },
      },
    ]);
  };

  // ── Refuser une proposition ──────────────────────────────
  const handleRefuser = (propId: number) => {
    Alert.alert('Refuser', 'Refuser cette proposition ?', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Refuser',
        style: 'destructive',
        onPress: async () => {
          try {
            await propositionService.updateStatut(propId, 'REFUSEE');
            await fetchMessages(true);
          } catch {
            Alert.alert('Erreur', 'Impossible de refuser');
          }
        },
      },
    ]);
  };

  // ── Contre-offre ─────────────────────────────────────────
  const handleContreOffre = async (propId: number) => {
    if (!contreOffreTxt.trim()) return;
    await sendMessage(`Contre-offre : ${contreOffreTxt}`);
    setContreOffreId(null);
    setContreOffreTxt('');
  };

  // ── Avatar initiale robuste ──────────────────────────────
  const getInitiale = (name: string) =>
    (name ?? 'U').trim().charAt(0).toUpperCase();

  // ── Rendu d'une bulle ────────────────────────────────────
  const renderMessage = ({ item }: { item: MessageLocal }) => {
    const isMine = item.auteurId === user?.id;

    if (item.type === 'SYSTEME') {
      return (
        <View style={s.systemMsg}>
          <Text style={s.systemTxt}>{item.contenu}</Text>
        </View>
      );
    }

    if (item.type === 'PROPOSITION' && item.proposition) {
      const p = item.proposition;
      const statutColor =
        p.statut === 'ACCEPTEE' ? '#10B981' :
        p.statut === 'REFUSEE'  ? '#EF4444' : C.primary;
      const statutLabel =
        p.statut === 'ACCEPTEE' ? '✅ Acceptée' :
        p.statut === 'REFUSEE'  ? '❌ Refusée'  :
        p.statut === 'CONTRE_OFFRE' ? '🔄 Contre-offre' : '⏳ En attente';
      return (
        <View style={[s.propCard, isMine && s.propCardMine]}>
          <View style={s.propHeader}>
            <Text style={s.propTitle}>📋 Proposition d'échange</Text>
            <View style={[s.propStatut, { backgroundColor: statutColor + '22', borderColor: statutColor }]}>
              <Text style={[s.propStatutTxt, { color: statutColor }]}>{statutLabel}</Text>
            </View>
          </View>
          <View style={s.propRow}>
            <View style={s.propItem}>
              <Text style={s.propItemLabel}>{p.sentByMe ? 'Vous offrez' : 'Il offre'}</Text>
              <Text style={s.propItemTxt}>{p.offre.titre}</Text>
              <Text style={s.propItemVal}>{p.offre.valeur.toLocaleString()} FCFA</Text>
            </View>
            <Text style={s.propArrow}>⇄</Text>
            <View style={s.propItem}>
              <Text style={s.propItemLabel}>{p.sentByMe ? 'Vous recevez' : 'Il demande'}</Text>
              <Text style={s.propItemTxt}>{p.recu.titre}</Text>
              <Text style={s.propItemVal}>{p.recu.valeur.toLocaleString()} FCFA</Text>
            </View>
          </View>
          {p.statut === 'EN_ATTENTE' && !p.sentByMe && (
            <View style={s.propActions}>
              <TouchableOpacity style={s.btnAccepter} onPress={() => handleAccepter(p.id)}>
                <Text style={s.btnAccepterTxt}>✅ Accepter</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.btnRefuser} onPress={() => handleRefuser(p.id)}>
                <Text style={s.btnRefuserTxt}>❌ Refuser</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.btnContre} onPress={() => setContreOffreId(p.id)}>
                <Text style={s.btnContreTxt}>🔄 Contre</Text>
              </TouchableOpacity>
            </View>
          )}
          {contreOffreId === p.id && (
            <View style={s.contreRow}>
              <TextInput
                style={s.contreInput}
                placeholder="Ta contre-offre..."
                placeholderTextColor="#999"
                value={contreOffreTxt}
                onChangeText={setContreOffreTxt}
              />
              <TouchableOpacity style={s.contreBtn} onPress={() => handleContreOffre(p.id)}>
                <Text style={{ color: '#fff', fontWeight: '700' }}>OK</Text>
              </TouchableOpacity>
            </View>
          )}
          <Text style={s.propTime}>{item.createdAt}</Text>
        </View>
      );
    }

    return (
      <View style={[s.msgRow, isMine && s.msgRowMine]}>
        {!isMine && (
          <View style={s.avatar}>
            <Text style={s.avatarTxt}>{getInitiale(partnerName)}</Text>
          </View>
        )}
        <View style={[s.bubble, isMine ? s.bubbleMine : s.bubbleOther, item._pending && s.bubblePending]}>
          <Text style={[s.bubbleTxt, isMine && s.bubbleTxtMine]}>{item.contenu}</Text>
          <View style={s.bubbleFooter}>
            {item._pending && <Text style={s.pendingDot}>⏳</Text>}
            <Text style={[s.bubbleTime, isMine && { color: '#ffffff80' }]}>{item.createdAt}</Text>
          </View>
        </View>
      </View>
    );
  };

  // ── UI ───────────────────────────────────────────────────
  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: '#F8FAFB' }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />

      {/* Header */}
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => router.back()} style={s.backBtn}>
          <Text style={s.backArrow}>←</Text>
        </TouchableOpacity>
        <View style={s.headerInfo}>
          <View style={s.headerAvatar}>
            <Text style={s.headerAvatarTxt}>{getInitiale(partnerName)}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.headerName}>{partnerName}</Text>
            <Text style={s.headerSub} numberOfLines={1}>{annonceTitle ?? 'Conversation'}</Text>
          </View>
        </View>
        {/* Bouton confirmation si une proposition acceptée existe */}
        {messages.some(m => m.proposition?.statut === 'ACCEPTEE') && (
          <TouchableOpacity
            style={{ backgroundColor: '#10B981', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7 }}
onPress={async () => {
  const propAcceptee = messages.find(m => m.proposition?.statut === 'ACCEPTEE');
  if (!propAcceptee?.proposition?.id) return;
  try {
    const { transactionService } = await import('../../services/api');
    const res = await transactionService.creerDepuisProposition(propAcceptee.proposition.id);
    router.push(`/confirmation/${res.data.id}` as any);
  } catch {
    Alert.alert('Erreur', 'Impossible de créer la transaction');
  }
}}>
            <Text style={{ color: '#fff', fontSize: 11, fontWeight: '800' }}>✅ Confirmer</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Messages */}
      {loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={C.primary} size="large" />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={m => `${m._tempId ?? m.id}`}
          renderItem={renderMessage}
          contentContainerStyle={s.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchMessages(); }} />
          }
          ListEmptyComponent={
            <View style={s.empty}>
              <Text style={s.emptyTxt}>Aucun message. Commence la conversation ! 👋</Text>
            </View>
          }
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
        />
      )}

      {/* Quick replies */}
      {messages.filter(m => !m._pending).length <= 1 && (
        <View style={s.quickRow}>
          {QUICK_REPLIES.map(r => (
            <TouchableOpacity key={r} style={s.quickChip} onPress={() => sendMessage(r)}>
              <Text style={s.quickTxt}>{r}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* Zone de saisie */}
      <View style={s.inputRow}>
        <TextInput
          style={s.input}
          placeholder="Message..."
          placeholderTextColor="#AAB"
          value={texte}
          onChangeText={setTexte}
          multiline
          maxLength={500}
        />
        <TouchableOpacity
          style={[s.sendBtn, (!texte.trim() || sending) && s.sendBtnDisabled]}
          onPress={() => sendMessage()}
          disabled={!texte.trim() || sending}
        >
          {sending
            ? <ActivityIndicator color="#fff" size="small" />
            : <Text style={s.sendIcon}>➤</Text>
          }
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

function makeStyles(C: any) {
  return StyleSheet.create({ 
  header:          { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', paddingTop: 52, paddingBottom: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#EEF0F3', gap: 12 },
  backBtn:         { width: 38, height: 38, borderRadius: 12, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center' },
  backArrow:       { fontSize: 18, color: '#1A2233' },
  headerInfo:      { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  headerAvatar:    { width: 40, height: 40, borderRadius: 20, backgroundColor: C.primary + '22', alignItems: 'center', justifyContent: 'center' },
  headerAvatarTxt: { fontSize: 17, fontWeight: '700', color: C.primary },
  headerName:      { fontSize: 15, fontWeight: '700', color: '#1A2233' },
  headerSub:       { fontSize: 12, color: '#8A95A8', marginTop: 1 },
  list:            { paddingHorizontal: 16, paddingVertical: 12, gap: 10 },
  msgRow:          { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  msgRowMine:      { flexDirection: 'row-reverse' },
  avatar:          { width: 32, height: 32, borderRadius: 16, backgroundColor: '#E8EAF6', alignItems: 'center', justifyContent: 'center' },
  avatarTxt:       { fontSize: 13, fontWeight: '700', color: '#5C6BC0' },
  bubble:          { maxWidth: '72%', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18, borderBottomLeftRadius: 4 },
  bubbleMine:      { backgroundColor: C.primary, borderBottomLeftRadius: 18, borderBottomRightRadius: 4 },
  bubbleOther:     { backgroundColor: '#fff', shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { width: 0, height: 1 }, elevation: 1 },
  bubblePending:   { opacity: 0.65 },
  bubbleTxt:       { fontSize: 15, color: '#1A2233', lineHeight: 21 },
  bubbleTxtMine:   { color: '#fff' },
  bubbleFooter:    { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', gap: 4, marginTop: 4 },
  bubbleTime:      { fontSize: 10, color: '#AAB4C0' },
  pendingDot:      { fontSize: 9 },
  systemMsg:       { alignSelf: 'center', backgroundColor: '#F0F4FF', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6, marginVertical: 4 },
  systemTxt:       { fontSize: 12, color: '#6B7280', fontStyle: 'italic' },
  propCard:        { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginHorizontal: 4, shadowColor: '#000', shadowOpacity: 0.07, shadowRadius: 8, elevation: 2, borderLeftWidth: 3, borderLeftColor: C.primary },
  propCardMine:    { borderLeftColor: '#6366F1' },
  propHeader:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  propTitle:       { fontSize: 13, fontWeight: '700', color: '#1A2233' },
  propStatut:      { borderRadius: 20, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 3 },
  propStatutTxt:   { fontSize: 11, fontWeight: '700' },
  propRow:         { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  propItem:        { flex: 1, backgroundColor: '#F8FAFB', borderRadius: 10, padding: 10 },
  propItemLabel:   { fontSize: 10, color: '#8A95A8', fontWeight: '600', marginBottom: 4 },
  propItemTxt:     { fontSize: 13, fontWeight: '600', color: '#1A2233' },
  propItemVal:     { fontSize: 12, color: C.primary, fontWeight: '700', marginTop: 2 },
  propArrow:       { fontSize: 18, color: C.primary },
  propActions:     { flexDirection: 'row', gap: 8, marginTop: 4 },
  btnAccepter:     { flex: 1, backgroundColor: '#10B981', borderRadius: 10, paddingVertical: 9, alignItems: 'center' },
  btnAccepterTxt:  { color: '#fff', fontWeight: '700', fontSize: 13 },
  btnRefuser:      { flex: 1, backgroundColor: '#FEE2E2', borderRadius: 10, paddingVertical: 9, alignItems: 'center' },
  btnRefuserTxt:   { color: '#EF4444', fontWeight: '700', fontSize: 13 },
  btnContre:       { flex: 1, backgroundColor: '#FFF7ED', borderRadius: 10, paddingVertical: 9, alignItems: 'center' },
  btnContreTxt:    { color: '#F59E0B', fontWeight: '700', fontSize: 13 },
  contreRow:       { flexDirection: 'row', gap: 8, marginTop: 10 },
  contreInput:     { flex: 1, backgroundColor: '#F3F4F6', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9, fontSize: 14, color: '#1A2233' },
  contreBtn:       { backgroundColor: C.primary, borderRadius: 10, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center' },
  propTime:        { fontSize: 10, color: '#AAB4C0', marginTop: 8, textAlign: 'right' },
  quickRow:        { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 12, paddingVertical: 8, gap: 8, backgroundColor: '#F8FAFB' },
  quickChip:       { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E5E7EB' },
  quickTxt:        { fontSize: 13, color: '#374151', fontWeight: '500' },
  inputRow:        { flexDirection: 'row', alignItems: 'flex-end', gap: 10, paddingHorizontal: 14, paddingVertical: 10, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#EEF0F3' },
  input:           { flex: 1, backgroundColor: '#F3F4F6', borderRadius: 22, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15, color: '#1A2233', maxHeight: 100 },
  sendBtn:         { width: 44, height: 44, borderRadius: 22, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' },
  sendBtnDisabled: { backgroundColor: '#CBD5E1' },
  sendIcon:        { color: '#fff', fontSize: 16 },
  empty:           { alignItems: 'center', marginTop: 80 },
  emptyTxt:        { color: '#9CA3AF', fontSize: 15 },
});
}